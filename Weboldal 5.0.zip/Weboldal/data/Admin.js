(() => {
  const userTableBody = document.getElementById('userTableBody');
  const rowTemplate = document.getElementById('userRowTemplate');
  const filters = document.querySelectorAll('.filter-btn');
  const searchInput = document.getElementById('userSearch');
  const adminMessage = document.getElementById('adminMessage');
  const modal = document.getElementById('editUserModal');
  const editForm = document.getElementById('editUserForm');
  const modalCloseBtn = document.querySelector('.close-modal');
  const cancelModalBtn = document.getElementById('cancelModal');
  const stats = {
    total: document.getElementById('totalUsers'),
    active: document.getElementById('activeUsers'),
    online: document.getElementById('onlineUsers'),
    blocked: document.getElementById('blockedUsers')
  };

  let cachedUsers = [];
  let currentFilter = 'all';
  let refreshTimer;

  const STATUS_LABELS = {
    active: 'Aktív',
    disabled: 'Letiltva'
  };

  const ONLINE_LABELS = {
    online: 'Online',
    offline: 'Offline'
  };

  const MIN_PASSWORD = 6;

  async function loadUsers(showLoader = true, clearMessage = false) {
    if (showLoader) {
      userTableBody.innerHTML = '<tr><td colspan="5" class="loading-row">Adatok frissítése...</td></tr>';
    }

    try {
      const response = await fetch('php/admin_users.php', { credentials: 'same-origin' });
      if (!response.ok) {
        throw new Error('Szerver hiba');
      }
      const data = await response.json();
      if (!data.success) {
        throw new Error('Nincs jogosultság vagy hiba történt');
      }
      cachedUsers = data.users || [];
      renderUsers();
      updateStats();
      if (clearMessage) {
        setMessage();
      }
    } catch (error) {
      console.error(error);
      setMessage('error', 'Nem sikerült betölteni az adatokat.');
      userTableBody.innerHTML = '<tr><td colspan="5" class="loading-row">Hiba történt a lekérés során.</td></tr>';
    }
  }

  function renderUsers() {
    const query = searchInput.value.trim().toLowerCase();
    const filtered = cachedUsers.filter(user => filterByStatus(user) && filterBySearch(user, query));

    if (filtered.length === 0) {
      userTableBody.innerHTML = '<tr><td colspan="5" class="loading-row">Nincs megjeleníthető felhasználó.</td></tr>';
      return;
    }

    const fragment = document.createDocumentFragment();

    filtered.forEach(user => {
      const clone = rowTemplate.content.cloneNode(true);
      clone.querySelector('.user-name').textContent = user.username;
      clone.querySelector('.user-id').textContent = `#${user.id}`;
      clone.querySelector('.user-email').textContent = user.email;
      clone.querySelector('.user-last-active').textContent = formatLastActive(user.last_active);

      const statusPill = clone.querySelector('.status-pill');
      const onlineState = user.online ? 'online' : 'offline';

      statusPill.textContent = `${STATUS_LABELS[user.status] ?? user.status} · ${ONLINE_LABELS[onlineState]}`;
      statusPill.classList.add(user.online ? 'online' : 'offline');
      if (user.status === 'disabled') {
        statusPill.classList.add('disabled');
      }

      const editBtn = clone.querySelector('.edit-btn');
      editBtn.addEventListener('click', () => openModal(user));

      const toggleBtn = clone.querySelector('.toggle-btn');
      toggleBtn.textContent = user.status === 'disabled' ? 'Feloldás' : 'Letiltás';
      toggleBtn.addEventListener('click', () => toggleStatus(user));

      const deleteBtn = clone.querySelector('.delete-btn');
      deleteBtn.addEventListener('click', () => deleteUser(user));

      fragment.appendChild(clone);
    });

    userTableBody.innerHTML = '';
    userTableBody.appendChild(fragment);
  }

  function filterByStatus(user) {
    switch (currentFilter) {
      case 'online':
        return user.status === 'active' && user.online;
      case 'offline':
        return user.status === 'active' && !user.online;
      case 'disabled':
        return user.status === 'disabled';
      default:
        return true;
    }
  }

  function filterBySearch(user, searchTerm) {
    if (!searchTerm) return true;
    return (
      user.username.toLowerCase().includes(searchTerm) ||
      user.email.toLowerCase().includes(searchTerm)
    );
  }

  function formatLastActive(timestamp) {
    if (!timestamp) return 'Nincs adat';
    const date = new Date(timestamp.replace(' ', 'T'));
    if (Number.isNaN(date.getTime())) return timestamp;
    return date.toLocaleString('hu-HU', { hour12: false });
  }

  function updateStats() {
    const total = cachedUsers.length;
    const blocked = cachedUsers.filter(user => user.status === 'disabled').length;
    const active = total - blocked;
    const online = cachedUsers.filter(user => user.status === 'active' && user.online).length;

    stats.total.textContent = total.toString();
    stats.blocked.textContent = blocked.toString();
    stats.active.textContent = active.toString();
    stats.online.textContent = online.toString();
  }

  function setMessage(type, text) {
    if (!adminMessage) return;

    if (!type || !text) {
      adminMessage.hidden = true;
      adminMessage.textContent = '';
      adminMessage.className = 'admin-message';
      return;
    }

    adminMessage.hidden = false;
    adminMessage.textContent = text;
    adminMessage.className = `admin-message ${type}`;
  }

  function openModal(user) {
    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
    editForm.reset();
    editForm.user_id.value = user.id;
    editForm.username.value = user.username;
    editForm.email.value = user.email;
    editForm.password.value = '';
    editForm.username.focus();
  }

  function closeModal() {
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
  }

  async function toggleStatus(user) {
    const targetStatus = user.status === 'disabled' ? 'active' : 'disabled';
    const actionText = targetStatus === 'disabled' ? 'le akarod tiltani' : 'engedélyezni szeretnéd';

    const confirmed = window.confirm(`Biztos, hogy ${actionText} ${user.username} felhasználót?`);
    if (!confirmed) return;

    const formData = new FormData();
    formData.append('action', 'update_status');
    formData.append('user_id', user.id);
    formData.append('status', targetStatus);

    await submitAdminAction(formData, `${user.username} státusza frissítve.`);
  }

  async function deleteUser(user) {
    const confirmed = window.confirm(`Végleg törölni szeretnéd ${user.username} felhasználót? Ez nem vonható vissza.`);
    if (!confirmed) return;

    const formData = new FormData();
    formData.append('action', 'delete_user');
    formData.append('user_id', user.id);

    await submitAdminAction(formData, `${user.username} törölve.`);
  }

  async function submitAdminAction(formData, successMessage) {
    try {
      const response = await fetch('php/admin_users.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Ismeretlen hiba');
      }

      setMessage('success', successMessage);
      await loadUsers(false);
    } catch (error) {
      console.error(error);
      setMessage('error', 'A művelet nem sikerült.');
    }
  }

  function handleFilterClick(event) {
    const button = event.currentTarget;
    filters.forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    currentFilter = button.dataset.filter ?? 'all';
    renderUsers();
  }

  function initFilters() {
    filters.forEach(btn => btn.addEventListener('click', handleFilterClick));
  }

  function initSearch() {
    searchInput.addEventListener('input', () => {
      renderUsers();
    });
  }

  function initModal() {
    modal.addEventListener('click', event => {
      if (event.target === modal) {
        closeModal();
      }
    });
    modalCloseBtn.addEventListener('click', closeModal);
    cancelModalBtn.addEventListener('click', closeModal);
  }

  editForm.addEventListener('submit', async event => {
    event.preventDefault();

    const formData = new FormData(editForm);
    const password = formData.get('password');

    if (password && password.toString().length > 0 && password.toString().length < MIN_PASSWORD) {
      setMessage('error', `A jelszó legyen legalább ${MIN_PASSWORD} karakter.`);
      return;
    }

    formData.append('action', 'update_profile');

    await submitAdminAction(formData, 'Felhasználói adatok frissítve.');
    closeModal();
  });

  function scheduleAutoRefresh() {
    if (refreshTimer) {
      clearInterval(refreshTimer);
    }
    refreshTimer = setInterval(() => loadUsers(false), 45000);
  }

  function startActivityPing() {
    const endpoint = 'php/update_activity.php';
    const ping = () => {
      fetch(endpoint, { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    };
    ping();
    setInterval(ping, 60000);
  }

  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
      loadUsers(false);
    }
  });

  initFilters();
  initSearch();
  initModal();
  loadUsers(true, true);
  scheduleAutoRefresh();
  startActivityPing();
})();
