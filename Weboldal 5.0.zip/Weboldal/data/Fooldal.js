// Letöltés gomb animáció
document.addEventListener('DOMContentLoaded', function() {
    const downloadBtn = document.getElementById('DownloadBTN');
    const progressBar = downloadBtn.querySelector('.progress-bar');
    const link = downloadBtn.querySelector('a');
    
    downloadBtn.addEventListener('click', function(e) {
        if (downloadBtn.classList.contains('downloading')) {
            e.preventDefault();
            return;
        }
        
        // Animáció indítása
        downloadBtn.classList.add('downloading');
        
        // Szimulált progress bar animáció
        let progress = 0;
        const progressInterval = setInterval(() => {
            progress += Math.random() * 30;
            if (progress > 100) {
                progress = 100;
            }
            
            progressBar.style.width = progress + '%';
            
            if (progress >= 100) {
                clearInterval(progressInterval);
                // Egy kis késleltetés, majd eltávolítjuk az animációt
                setTimeout(() => {
                    downloadBtn.classList.remove('downloading');
                    progressBar.style.width = '0%';
                }, 1000);
            }
        }, 200);
        
        // A link által generált letöltés feldolgozása
        setTimeout(() => {
            link.click();
        }, 300);
    });
});

// Avatar betöltése főoldalon
document.addEventListener('DOMContentLoaded', function() {
    const profilePic = document.getElementById('profilePic');
    
    if (profilePic) {
        fetch('php/get_profile.php')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.user && data.user.avatar) {
                    profilePic.style.setProperty('background-image', 'url(' + data.user.avatar + ')', 'important');
                    profilePic.style.setProperty('background-size', 'cover', 'important');
                    profilePic.style.setProperty('background-position', 'center', 'important');
                } else {
                    // Alapértelmezett gradient, ha nincs avatar
                    profilePic.style.background = 'linear-gradient(135deg, #ceaf01, #ceaf01)';
                }
            })
            .catch(error => {
                console.error('Error loading avatar:', error);
                // Alapértelmezett gradient hiba esetén
                profilePic.style.background = 'linear-gradient(135deg, #ceaf01, #ceaf01)';
            });
    }
});

// Profil menü kezelése
document.addEventListener('DOMContentLoaded', function() {
    const profileMenuBtn = document.getElementById('profileMenuBtn');
    const profileDropdown = document.getElementById('profileDropdown');
    
    if (!profileMenuBtn || !profileDropdown) {
        return;
    }
    
    // Menü nyitás/zárás
    profileMenuBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        profileDropdown.classList.toggle('active');
    });
    
    // Menü zárás kívülre kattintáskor
    document.addEventListener('click', function(e) {
        if (!profileMenuBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
            profileDropdown.classList.remove('active');
        }
    });
    
    // Menü zárás link kattintáskor
    const dropdownLinks = profileDropdown.querySelectorAll('a');
    dropdownLinks.forEach(link => {
        link.addEventListener('click', function() {
            profileDropdown.classList.remove('active');
        });
    });
});

// ===== PROFIL MODAL =====
document.addEventListener('DOMContentLoaded', function() {
    const profilePic = document.getElementById('profilePic');
    const profileModal = document.getElementById('profileModal');
    const closeModal = document.getElementById('closeProfileModal');
    const profileForm = document.getElementById('profileEditForm');
    const avatarInput = document.getElementById('avatarInput');
    const avatarPreview = document.getElementById('avatarPreview');
    const profileMessage = document.getElementById('profileMessage');
    
    // Profil modal megnyitása
    if (profilePic) {
        profilePic.addEventListener('click', function() {
            openProfileModal();
        });
    }
    
    // Modal bezárása
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            closeProfileModal();
        });
    }
    
    // Modal bezárása kívülre kattintáskor
    if (profileModal) {
        profileModal.addEventListener('click', function(e) {
            if (e.target === profileModal) {
                closeProfileModal();
            }
        });
    }
    
    // Avatar preview
    if (avatarInput) {
        avatarInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    if (avatarPreview) {
                        avatarPreview.style.setProperty('background-image', 'url(' + event.target.result + ')', 'important');
                        avatarPreview.style.setProperty('background-size', 'cover', 'important');
                        avatarPreview.style.setProperty('background-position', 'center', 'important');
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Avatar preview kattintásra
    if (avatarPreview) {
        avatarPreview.addEventListener('click', function() {
            if (avatarInput) {
                avatarInput.click();
            }
        });
    }
    
    // Password toggle gombok
    const passwordToggles = [
        { btn: 'toggleEmailPassword', input: 'emailPassword' },
        { btn: 'toggleCurrentPassword', input: 'currentPassword' },
        { btn: 'toggleNewPassword', input: 'newPassword' },
        { btn: 'toggleConfirmPassword', input: 'confirmPassword' }
    ];
    
    passwordToggles.forEach(toggle => {
        const btn = document.getElementById(toggle.btn);
        const input = document.getElementById(toggle.input);
        
        if (btn && input) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                if (input.type === 'password') {
                    input.type = 'text';
                    btn.textContent = '👁️';
                } else {
                    input.type = 'password';
                    btn.textContent = '👁️‍🗨️';
                }
            });
        }
    });
    
    // Form submission
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(profileForm);
            
            fetch('php/update_profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showProfileMessage('Profil sikeresen frissítve!', 'success');
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                } else {
                    showProfileMessage(data.error || 'Hiba történt a profil frissítésekor!', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showProfileMessage('Hálózati hiba történt!', 'error');
            });
        });
    }
    
    // Modal megnyitása és adatok betöltése
    function openProfileModal() {
        if (!profileModal) return;
        
        profileModal.classList.add('active');
        loadProfileData();
    }
    
    // Modal bezárása
    function closeProfileModal() {
        if (!profileModal) return;
        profileModal.classList.remove('active');
    }
    
    // Profil adatok betöltése
    function loadProfileData() {
        fetch('php/get_profile.php')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.user) {
                    const user = data.user;
                    document.getElementById('firstName').value = user.first_name || '';
                    document.getElementById('lastName').value = user.last_name || '';
                    document.getElementById('email').value = user.email || '';
                    document.getElementById('profileBio').value = user.bio || '';
                    
                    if (user.avatar) {
                        avatarPreview.style.setProperty('background-image', 'url(' + user.avatar + ')', 'important');
                        avatarPreview.style.setProperty('background-size', 'cover', 'important');
                        avatarPreview.style.setProperty('background-position', 'center', 'important');
                    }
                    
                    // Avatar input reset
                    avatarInput.value = '';
                } else {
                    showProfileMessage(data.error || 'Hiba az adatok betöltésekor!', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showProfileMessage('Hálózati hiba történt!', 'error');
            });
    }
    
    // Üzenet megjelenítése
    function showProfileMessage(message, type) {
        profileMessage.textContent = message;
        profileMessage.className = 'message ' + type;
        profileMessage.style.display = 'block';
        
        if (type === 'error') {
            setTimeout(() => {
                profileMessage.style.display = 'none';
            }, 5000);
        }
    }
});

/* ===== JÁTÉK GALÉRIÁJA ===== */
document.addEventListener('DOMContentLoaded', function() {
    const mainGalleryImage = document.getElementById('mainGalleryImage');
    const galleryThumbnails = document.getElementById('galleryThumbnails');
    const prevBtn = document.getElementById('prevGalleryBtn');
    const nextBtn = document.getElementById('nextGalleryBtn');
    const currentIndexSpan = document.getElementById('currentImageIndex');
    const totalImagesSpan = document.getElementById('totalImages');
    
    let currentImageIndex = 0;
    const totalImages = 6; // Placeholder képek száma
    let autoplayInterval = null;
    
    // Galériamegjelenítés frissítése
    function updateGallery() {

    //  FŐ KÉP FRISSÍTÉSE
    const selectedThumbnail = document.querySelectorAll('.thumbnail')[currentImageIndex];
    const thumbnailImg = selectedThumbnail.querySelector('img');
    mainGalleryImage.src = thumbnailImg.src;

    // Aktív thumbnail jelzése
    document.querySelectorAll('.thumbnail').forEach((thumb, index) => {
        if (index === currentImageIndex) {
            thumb.classList.add('active');
        } else {
            thumb.classList.remove('active');
        }
    });

    // Indexek frissítése
    currentIndexSpan.textContent = currentImageIndex + 1;
    totalImagesSpan.textContent = totalImages;

    prevBtn.disabled = false;
    nextBtn.disabled = false;
}
    
    // Autoplay funkcionalitás
    function startAutoplay() {
        autoplayInterval = setInterval(() => {
            currentImageIndex = (currentImageIndex + 1) % totalImages;
            updateGallery();
        }, 3000); // 3 másodpercenként váltson
    }
    
    // Autoplay leállítása
    function stopAutoplay() {
        if (autoplayInterval) {
            clearInterval(autoplayInterval);
            autoplayInterval = null;
        }
    }
    
    // Autoplay újraindítása
    function resetAutoplay() {
        stopAutoplay();
        startAutoplay();
    }
    
    // Thumbnail kattintás
    if (galleryThumbnails) {
        galleryThumbnails.querySelectorAll('.thumbnail').forEach((thumb, index) => {
            thumb.addEventListener('click', function() {
                currentImageIndex = index;
                updateGallery();
                resetAutoplay();
            });
        });
    }
    
    // Lapozó gombok
    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            currentImageIndex = (currentImageIndex - 1 + totalImages) % totalImages;
            updateGallery();
            resetAutoplay();
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            currentImageIndex = (currentImageIndex + 1) % totalImages;
            updateGallery();
            resetAutoplay();
        });
    }
    
    // Billentyűzet navigáció
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft') {
            currentImageIndex = (currentImageIndex - 1 + totalImages) % totalImages;
            updateGallery();
            resetAutoplay();
        } else if (e.key === 'ArrowRight') {
            currentImageIndex = (currentImageIndex + 1) % totalImages;
            updateGallery();
            resetAutoplay();
        }
    });
    
    // Kezdeti galériamegjelenítés
    updateGallery();
    startAutoplay();
});

// Felhasználói aktivitás pingelése az online státuszhoz
document.addEventListener('DOMContentLoaded', function() {
    const pingEndpoint = 'php/update_activity.php';

    function sendPing() {
        fetch(pingEndpoint, {
            method: 'POST',
            credentials: 'same-origin'
        }).catch(error => console.warn('Aktivitás ping hiba:', error));
    }

    sendPing();
    setInterval(sendPing, 60000);
});




