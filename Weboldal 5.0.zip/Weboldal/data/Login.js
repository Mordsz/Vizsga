// Bejelentkezési form kezelése
document.addEventListener('DOMContentLoaded', function () {

  const loginForm = document.getElementById('loginForm');
  const messageBox = document.getElementById('error-message');

  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const formData = new FormData(loginForm);

      fetch('php/login_process.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin', // session cookie mentés
        headers: {
          'Accept': 'application/json'
        }
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Hálózati hiba történt');
        }
        return response.json();
      })
      .then(data => {

        if (data.success) {

          setTimeout(() => {
            window.location.href = 'main.php';
          }, 100);

        } else {

          const messages = {
            'invalid_credentials': 'Helytelen felhasználónév vagy jelszó.',
            'missing_fields': 'Mindkét mező kitöltése kötelező.',
            'invalid_method': 'Hiba történt a feldolgozás során.',
            'server_error': 'Szerverhiba történt, próbáld újra később.',
            'account_disabled': 'A fiók jelenleg le van tiltva.'
          };

          messageBox.textContent = messages[data.error] || 'Ismeretlen hiba történt.';
          messageBox.style.display = 'block';
        }

      })
      .catch(error => {
        console.error('Login hiba:', error);
        messageBox.textContent = 'Váratlan hiba történt, próbáld meg később.';
        messageBox.style.display = 'block';
      });

    });
  }


  // Jelszó megjelenítés/elrejtés
  const togglePassword = document.getElementById('togglePassword');
  const passwordField = document.getElementById('passwordField');

  if (togglePassword && passwordField) {
    togglePassword.addEventListener('click', function (e) {
      e.preventDefault();

      if (passwordField.type === 'password') {
        passwordField.type = 'text';
      } else {
        passwordField.type = 'password';
      }
    });
  }

});