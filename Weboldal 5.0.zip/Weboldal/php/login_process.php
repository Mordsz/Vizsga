<?php
declare(strict_types=1);
header('Content-Type: application/json');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
require __DIR__ . '/config.php';
require __DIR__ . '/schema_helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'invalid_method']);
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    echo json_encode(['success' => false, 'error' => 'missing_fields']);
    exit;
}

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    $hasIsAdmin = usersColumnExists($db, 'is_admin');
    $hasAccountStatus = usersColumnExists($db, 'account_status');
    $hasLastActive = usersColumnExists($db, 'last_active');
    $hasLastLogin = usersColumnExists($db, 'last_login');

    $selectFields = ['id', 'password'];
    $selectFields[] = $hasIsAdmin ? 'is_admin' : '0 AS is_admin';
    $selectFields[] = $hasAccountStatus ? 'account_status' : "'active' AS account_status";
    $query = 'SELECT ' . implode(', ', $selectFields) . ' FROM users WHERE username = ? LIMIT 1';

    $stmt = $db->prepare($query);
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        $stmt->close();
        $db->close();
        echo json_encode(['success' => false, 'error' => 'invalid_credentials']);
        exit;
    }

    $stmt->bind_result($userId, $hashedPassword, $isAdmin, $accountStatus);
    $stmt->fetch();
    $stmt->close();

    if ($accountStatus !== 'active') {
        $db->close();
        echo json_encode(['success' => false, 'error' => 'account_disabled']);
        exit;
    }

    if (password_verify($password, $hashedPassword)) {
        $updateParts = [];
        if ($hasLastActive) {
            $updateParts[] = 'last_active = NOW()';
        }
        if ($hasLastLogin) {
            $updateParts[] = 'last_login = NOW()';
        }

        if (!empty($updateParts)) {
            $updateQuery = 'UPDATE users SET ' . implode(', ', $updateParts) . ' WHERE id = ?';
            $updateStmt = $db->prepare($updateQuery);
            $updateStmt->bind_param('i', $userId);
            $updateStmt->execute();
            $updateStmt->close();
        }

        $db->close();
        session_start();
        $_SESSION['user'] = $username;
        $_SESSION['user_id'] = $userId;
        $_SESSION['is_admin'] = $hasIsAdmin ? ((int)$isAdmin === 1) : false;
        echo json_encode([
            'success' => true,
            'username' => $username,
            'user_id' => $userId,
            'is_admin' => $_SESSION['is_admin']
        ]);
        exit;
    }

    $db->close();
    echo json_encode(['success' => false, 'error' => 'invalid_credentials']);
} catch (mysqli_sql_exception $exception) {
    error_log('Login error: ' . $exception->getMessage());
    echo json_encode(['success' => false, 'error' => 'server_error']);}