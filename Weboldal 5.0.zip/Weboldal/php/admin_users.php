<?php
declare(strict_types=1);

session_start();
header('Content-Type: application/json');

if (empty($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'not_authorized']);
    exit;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
require __DIR__ . '/config.php';
require __DIR__ . '/schema_helpers.php';

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');
    ensureUsersColumn($db, 'is_admin', 'TINYINT(1) NOT NULL DEFAULT 0');
    ensureUsersColumn($db, 'account_status', "ENUM('active','disabled') NOT NULL DEFAULT 'active'");
    ensureUsersColumn($db, 'last_active', 'DATETIME NULL DEFAULT NULL');

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $db->prepare('SELECT id, username, email, first_name, last_name, account_status, last_active FROM users WHERE is_admin = 0 ORDER BY username ASC');
        $stmt->execute();
        $result = $stmt->get_result();

        $users = [];
        $threshold = new DateTimeImmutable('-5 minutes');

        while ($row = $result->fetch_assoc()) {
            $lastActive = null;
            if (!empty($row['last_active'])) {
                try {
                    $lastActive = new DateTimeImmutable($row['last_active']);
                } catch (Exception $e) {
                    $lastActive = null;
                }
            }
            $users[] = [
                'id' => (int)$row['id'],
                'username' => $row['username'],
                'email' => $row['email'],
                'first_name' => $row['first_name'],
                'last_name' => $row['last_name'],
                'status' => $row['account_status'],
                'last_active' => $row['last_active'],
                'online' => $lastActive ? ($lastActive >= $threshold) : false
            ];
        }
        $stmt->close();
        $db->close();

        echo json_encode(['success' => true, 'users' => $users]);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'method_not_allowed']);
        exit;
    }

    $action = $_POST['action'] ?? '';
    $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    if ($userId <= 0) {
        echo json_encode(['success' => false, 'error' => 'invalid_user']);
        exit;
    }

    $checkStmt = $db->prepare('SELECT is_admin FROM users WHERE id = ?');
    $checkStmt->bind_param('i', $userId);
    $checkStmt->execute();
    $checkStmt->bind_result($targetIsAdmin);
    if (!$checkStmt->fetch()) {
        $checkStmt->close();
        echo json_encode(['success' => false, 'error' => 'user_not_found']);
        exit;
    }
    $checkStmt->close();

    if ((int)$targetIsAdmin === 1) {
        echo json_encode(['success' => false, 'error' => 'cannot_modify_admin']);
        exit;
    }

    switch ($action) {
        case 'update_profile':
            $updates = [];
            $types = '';
            $values = [];

            $newUsername = trim($_POST['username'] ?? '');
            $newEmail = trim($_POST['email'] ?? '');
            $newPassword = $_POST['password'] ?? '';

            if ($newUsername !== '') {
                $usernameStmt = $db->prepare('SELECT id FROM users WHERE username = ? AND id != ?');
                $usernameStmt->bind_param('si', $newUsername, $userId);
                $usernameStmt->execute();
                $usernameStmt->store_result();
                if ($usernameStmt->num_rows > 0) {
                    $usernameStmt->close();
                    echo json_encode(['success' => false, 'error' => 'username_exists']);
                    exit;
                }
                $usernameStmt->close();

                $updates[] = 'username = ?';
                $types .= 's';
                $values[] = $newUsername;
            }

            if ($newEmail !== '') {
                if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
                    echo json_encode(['success' => false, 'error' => 'invalid_email']);
                    exit;
                }

                $emailStmt = $db->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
                $emailStmt->bind_param('si', $newEmail, $userId);
                $emailStmt->execute();
                $emailStmt->store_result();
                if ($emailStmt->num_rows > 0) {
                    $emailStmt->close();
                    echo json_encode(['success' => false, 'error' => 'email_exists']);
                    exit;
                }
                $emailStmt->close();

                $updates[] = 'email = ?';
                $types .= 's';
                $values[] = $newEmail;
            }

            if ($newPassword !== '') {
                if (strlen($newPassword) < 6) {
                    echo json_encode(['success' => false, 'error' => 'password_short']);
                    exit;
                }

                $hashed = password_hash($newPassword, PASSWORD_BCRYPT);
                $updates[] = 'password = ?';
                $types .= 's';
                $values[] = $hashed;
            }

            if (empty($updates)) {
                echo json_encode(['success' => false, 'error' => 'no_changes']);
                exit;
            }

            $values[] = $userId;
            $types .= 'i';

            $updateQuery = 'UPDATE users SET ' . implode(', ', $updates) . ' WHERE id = ?';
            $updateStmt = $db->prepare($updateQuery);
            $updateStmt->bind_param($types, ...$values);
            $updateStmt->execute();
            $updateStmt->close();

            echo json_encode(['success' => true]);
            break;

        case 'update_status':
            $status = $_POST['status'] ?? '';
            if (!in_array($status, ['active', 'disabled'], true)) {
                echo json_encode(['success' => false, 'error' => 'invalid_status']);
                exit;
            }

            $statusStmt = $db->prepare('UPDATE users SET account_status = ?, last_active = CASE WHEN ? = \'disabled\' THEN DATE_SUB(NOW(), INTERVAL 1 HOUR) ELSE last_active END WHERE id = ?');
            $statusStmt->bind_param('ssi', $status, $status, $userId);
            $statusStmt->execute();
            $statusStmt->close();

            echo json_encode(['success' => true]);
            break;

        case 'delete_user':
            $deleteStmt = $db->prepare('DELETE FROM users WHERE id = ? AND is_admin = 0');
            $deleteStmt->bind_param('i', $userId);
            $deleteStmt->execute();
            $affected = $deleteStmt->affected_rows;
            $deleteStmt->close();

            if ($affected === 0) {
                echo json_encode(['success' => false, 'error' => 'delete_failed']);
                exit;
            }

            echo json_encode(['success' => true]);
            break;

        default:
            echo json_encode(['success' => false, 'error' => 'unknown_action']);
            break;
    }

    $db->close();
} catch (Exception $e) {
    error_log('Admin users error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'server_error']);
}
