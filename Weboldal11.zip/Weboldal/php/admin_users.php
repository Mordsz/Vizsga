<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$auth = require_auth();
if (!$auth['is_admin']) {
    json_error('not_authorized', 'Csak admin jogosultsággal érhető el', 403);
}

try {
    $db = db();
    ensure_user_columns([
        ['name' => 'is_admin', 'definition' => 'TINYINT(1) NOT NULL DEFAULT 0'],
        ['name' => 'account_status', 'definition' => "ENUM('active','disabled') NOT NULL DEFAULT 'active'"],
        ['name' => 'last_active', 'definition' => 'DATETIME NULL DEFAULT NULL'],
        ['name' => 'online_since', 'definition' => 'DATETIME NULL DEFAULT NULL'],
        ['name' => 'avatar', 'definition' => 'VARCHAR(255) DEFAULT NULL']
    ]);

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $db->prepare('SELECT id, username, email, first_name, last_name, account_status, last_active, is_admin, online_since, avatar FROM users ORDER BY username ASC');
        $stmt->execute();
        $result = $stmt->get_result();

        $users = [];
        $threshold = new DateTimeImmutable('-5 minutes');

        while ($row = $result->fetch_assoc()) {
            $lastActive = null;
            if (!empty($row['last_active'])) {
                try {
                    $lastActive = new DateTimeImmutable($row['last_active']);
                } catch (Throwable $ignored) {
                    $lastActive = null;
                }
            }

            $onlineTime = null;
            if (!empty($row['online_since']) && $lastActive && $lastActive >= $threshold) {
                try {
                    $since = new DateTimeImmutable($row['online_since']);
                    $now = new DateTimeImmutable();
                    $interval = $since->diff($now);
                    $onlineTime = $interval->format('%H:%I');
                } catch (Throwable $ignored) {
                    $onlineTime = null;
                }
            }

            $users[] = [
                'id' => (int)$row['id'],
                'username' => $row['username'],
                'email' => $row['email'],
                'first_name' => $row['first_name'],
                'last_name' => $row['last_name'],
                'status' => $row['account_status'],
                'last_active' => $row['last_active'],
                'online' => $lastActive ? ($lastActive >= $threshold) : false,
                'online_time' => $onlineTime,
                'is_admin' => (int)$row['is_admin'] === 1,
                'avatar' => $row['avatar']
            ];
        }
        $stmt->close();

        json_success(['users' => $users]);
    }

    require_method('POST');

    $action = $_POST['action'] ?? '';
    $userId = (int)($_POST['user_id'] ?? 0);
    if ($userId <= 0) {
        json_error('invalid_user', 'Érvénytelen felhasználó azonosító');
    }

    $stmt = $db->prepare('SELECT is_admin FROM users WHERE id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->bind_result($targetIsAdmin);
    if (!$stmt->fetch()) {
        $stmt->close();
        json_error('user_not_found', 'A felhasználó nem található');
    }
    $stmt->close();

    if ((int)$targetIsAdmin === 1) {
        json_error('cannot_modify_admin', 'Admin fiók nem módosítható');
    }

    switch ($action) {
        case 'update_profile':
            handleProfileUpdate($db, $userId);
            break;

        case 'update_status':
            handleStatusUpdate($db, $userId);
            break;

        case 'delete_user':
            handleDeleteUser($db, $userId);
            break;

        default:
            json_error('unknown_action', 'Ismeretlen admin művelet');
    }
} catch (Throwable $exception) {
    error_log('Admin users error: ' . $exception->getMessage());
    json_error('server_error', 'Szerverhiba történt', 500);
}

function handleProfileUpdate(mysqli $db, int $userId): void
{
    $updates = [];
    $types = '';
    $values = [];

    $newUsername = trim($_POST['username'] ?? '');
    $newEmail = trim($_POST['email'] ?? '');
    $newPassword = $_POST['password'] ?? '';

    if ($newUsername !== '') {
        $stmt = $db->prepare('SELECT id FROM users WHERE username = ? AND id != ?');
        $stmt->bind_param('si', $newUsername, $userId);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->close();
            json_error('username_exists', 'Ez a felhasználónév már foglalt');
        }
        $stmt->close();

        $updates[] = 'username = ?';
        $types .= 's';
        $values[] = $newUsername;
    }

    if ($newEmail !== '') {
        if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            json_error('invalid_email', 'Hibás email cím');
        }

        $stmt = $db->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
        $stmt->bind_param('si', $newEmail, $userId);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->close();
            json_error('email_exists', 'Ez az email cím már használatban van');
        }
        $stmt->close();

        $updates[] = 'email = ?';
        $types .= 's';
        $values[] = $newEmail;
    }

    if ($newPassword !== '') {
        if (strlen($newPassword) < 6) {
            json_error('password_short', 'A jelszó legyen legalább 6 karakter');
        }

        $updates[] = 'password = ?';
        $types .= 's';
        $values[] = password_hash($newPassword, PASSWORD_BCRYPT);
    }

    if ($updates === []) {
        json_error('no_changes', 'Nincs módosítandó adat');
    }

    $values[] = $userId;
    $types .= 'i';

    $query = 'UPDATE users SET ' . implode(', ', $updates) . ' WHERE id = ?';
    $stmt = $db->prepare($query);
    $stmt->bind_param($types, ...$values);
    $stmt->execute();
    $stmt->close();

    json_success();
}

function handleStatusUpdate(mysqli $db, int $userId): void
{
    $status = $_POST['status'] ?? '';
    if (!in_array($status, ['active', 'disabled'], true)) {
        json_error('invalid_status', 'Ismeretlen státusz');
    }

    $stmt = $db->prepare('UPDATE users SET account_status = ?, last_active = CASE WHEN ? = "disabled" THEN DATE_SUB(NOW(), INTERVAL 1 HOUR) ELSE last_active END WHERE id = ?');
    $stmt->bind_param('ssi', $status, $status, $userId);
    $stmt->execute();
    $stmt->close();

    json_success();
}

function handleDeleteUser(mysqli $db, int $userId): void
{
    $stmt = $db->prepare('DELETE FROM users WHERE id = ? AND is_admin = 0');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected === 0) {
        json_error('delete_failed', 'A felhasználó törlése nem sikerült');
    }

    json_success();
}
