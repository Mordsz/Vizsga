<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

require_method('POST');
$auth = require_auth();

try {
    $db = db();
    ensure_user_columns([
        ['name' => 'last_active', 'definition' => 'DATETIME NULL DEFAULT NULL'],
        ['name' => 'online_since', 'definition' => 'DATETIME NULL DEFAULT NULL']
    ]);

    $stmt = $db->prepare('UPDATE users SET last_active = NOW() WHERE id = ?');
    $stmt->bind_param('i', $auth['user_id']);
    $stmt->execute();
    $stmt->close();

    // Ha nincs online_since, beállítjuk
    $stmt2 = $db->prepare('UPDATE users SET online_since = NOW() WHERE id = ? AND online_since IS NULL');
    $stmt2->bind_param('i', $auth['user_id']);
    $stmt2->execute();
    $stmt2->close();

    json_success();
} catch (Throwable $exception) {
    error_log('Activity ping error: ' . $exception->getMessage());
    json_error('server_error', 'Szerverhiba történt', 500);
}
