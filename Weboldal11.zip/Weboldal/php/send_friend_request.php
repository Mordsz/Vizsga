<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

require_method('POST');
$auth = require_auth();

$username = trim($_POST['username'] ?? '');
if ($username === '') {
    json_error('invalid_username', 'Felhasználónév megadása kötelező');
}

try {
    $db = db();

    $stmt = $db->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $stmt->close();
        json_error('user_not_found', 'A megadott felhasználó nem található');
    }

    $receiverId = (int)$result->fetch_assoc()['id'];
    $stmt->close();

    if ($receiverId === $auth['user_id']) {
        json_error('self_request', 'Magadat nem veheted fel');
    }

    $stmt = $db->prepare('SELECT id FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?) LIMIT 1');
    $stmt->bind_param('iiii', $auth['user_id'], $receiverId, $receiverId, $auth['user_id']);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        json_error('already_friends', 'Már barátok vagytok');
    }
    $stmt->close();

    $stmt = $db->prepare('SELECT status FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) LIMIT 1');
    $stmt->bind_param('iiii', $auth['user_id'], $receiverId, $receiverId, $auth['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $status = $result->fetch_assoc()['status'];
        $stmt->close();
        $message = $status === 'pending' ? 'Már van függőben lévő kérés' : 'Korábban már volt kérelem köztetek';
        json_error('request_exists', $message);
    }
    $stmt->close();

    $stmt = $db->prepare("INSERT INTO friend_requests (sender_id, receiver_id, status) VALUES (?, ?, 'pending')");
    $stmt->bind_param('ii', $auth['user_id'], $receiverId);
    $stmt->execute();
    $stmt->close();

    json_success(['message' => 'Barátkérelem elküldve']);
} catch (Throwable $exception) {
    error_log('Send friend request error: ' . $exception->getMessage());
    json_error('server_error', 'Szerverhiba történt', 500);
}
