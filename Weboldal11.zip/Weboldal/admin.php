<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header('Location: main.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin vezérlőpult</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/admin.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <header class="admin-header">
    <div class="brand">
      <span class="brand-pill">TidesOfEnvy</span>
      <h1>Admin vezérlőpult</h1>
      <p>Felhasználók kezelése, státuszok figyelése, gyors beavatkozás.</p>
    </div>
    <div class="header-actions">
      <span class="session-user">👤 <?= htmlspecialchars($_SESSION['user'] ?? 'Admin') ?></span>
      <a class="ghost-btn" href="main.php">Vissza a főoldalra</a>
      <form action="php/logout.php" method="POST">
        <button type="submit" class="ghost-btn danger">Kijelentkezés</button>
      </form>
    </div>
  </header>

  <main class="admin-main">
    <section class="stats-grid" aria-live="polite">
      <article class="stat-card">
        <p>Aktív felhasználók</p>
        <strong id="activeUsers">0</strong>
      </article>
      <article class="stat-card">
        <p>Online jelenleg</p>
        <strong id="onlineUsers">0</strong>
      </article>
      <article class="stat-card">
        <p>Letiltott fiókok</p>
        <strong id="blockedUsers">0</strong>
      </article>
      <article class="stat-card">
        <p>Összes fiók</p>
        <strong id="totalUsers">0</strong>
      </article>
    </section>

    <section class="chart-section">
      <div class="chart-container">
        <h2>Online felhasználók diagramja</h2>
        <canvas id="onlineChart"></canvas>
      </div>
      <div class="toplist-container">
        <h2>Legtöbbet online felhasználók</h2>
        <ul id="toplist"></ul>
      </div>
    </section>

    <section class="table-card">
      <div class="table-card__head">
        <div>
          <h2>Felhasználók listája</h2>
          <p>Átlag felhasználók valós idejű státuszai.</p>
        </div>
        <div class="filters">
          <button class="filter-btn active" data-filter="all">Összes</button>
          <button class="filter-btn" data-filter="online">Online</button>
          <button class="filter-btn" data-filter="offline">Offline</button>
          <button class="filter-btn" data-filter="disabled">Letiltva</button>
        </div>
      </div>

      <div class="table-tools">
        <input type="search" id="userSearch" placeholder="Keresés név vagy email alapján...">
        <div id="adminMessage" class="admin-message" role="status" hidden></div>
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Felhasználó</th>
              <th>Email</th>
              <th>Státusz</th>
              <th>Utoljára aktív</th>
              <th>Műveletek</th>
            </tr>
          </thead>
          <tbody id="userTableBody">
            <tr>
              <td colspan="5" class="loading-row">Adatok betöltése...</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </main>

  <div class="modal" id="editUserModal" aria-hidden="true">
    <div class="modal__dialog" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
      <div class="modal__header">
        <h3 id="modalTitle">Felhasználó szerkesztése</h3>
        <button class="close-modal" type="button" aria-label="Modal bezárása">&times;</button>
      </div>
      <form id="editUserForm">
        <input type="hidden" name="user_id" id="modalUserId">
        <label>
          Felhasználónév
          <input type="text" name="username" id="modalUsername" minlength="3" maxlength="32" required>
        </label>
        <label>
          Email cím
          <input type="email" name="email" id="modalEmail" required>
        </label>
        <label>
          Új jelszó (opcionális)
          <input type="password" name="password" id="modalPassword" placeholder="Legalább 6 karakter">
        </label>
        <div class="modal__actions">
          <button type="button" class="ghost-btn" id="cancelModal">Mégse</button>
          <button type="submit" class="primary-btn">Mentés</button>
        </div>
      </form>
    </div>
  </div>

  <template id="userRowTemplate">
    <tr>
      <td class="user-col">
        <p class="user-name"></p>
        <span class="user-id"></span>
      </td>
      <td class="user-email"></td>
      <td>
        <span class="status-pill"></span>
      </td>
      <td class="user-last-active"></td>
      <td class="actions">
        <button class="ghost-btn primary edit-btn" type="button">Szerkesztés</button>
        <button class="ghost-btn toggle-btn" type="button"></button>
        <button class="ghost-btn danger delete-btn" type="button">Törlés</button>
      </td>
    </tr>
  </template>

  <script src="data/Admin.js" defer></script>
</body>
</html>
