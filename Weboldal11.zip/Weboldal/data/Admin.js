(() => {
  const dom = {
    tableBody: document.getElementById('userTableBody'),
    rowTemplate: document.getElementById('userRowTemplate'),
    filters: Array.from(document.querySelectorAll('.filter-btn')),
    searchInput: document.getElementById('userSearch'),
    adminMessage: document.getElementById('adminMessage'),
    modal: document.getElementById('editUserModal'),
    editForm: document.getElementById('editUserForm'),
    modalCloseBtn: document.querySelector('.close-modal'),
    cancelModalBtn: document.getElementById('cancelModal'),
    stats: {
      total: document.getElementById('totalUsers'),
      active: document.getElementById('activeUsers'),
      online: document.getElementById('onlineUsers'),
      blocked: document.getElementById('blockedUsers')
    },
    chartCanvas: document.getElementById('onlineChart'),
    toplist: document.getElementById('toplist')
  };

  const state = {
    users: [],
    filter: 'all',
    refreshTimer: null,
    chart: null,
    chartData: {
      labels: [],
      data: []
    },
    chartRefreshTimer: null
  };

  const LABELS = {
    status: { active: 'Aktív', disabled: 'Letiltva' },
    online: { true: 'Online', false: 'Offline' }
  };

  const MIN_PASSWORD = 6;

  const disableActionButton = (button, label = '') => {
    if (!button) return;
    button.disabled = true;
    button.classList.add('disabled-action');
    button.title = 'Admin fiók nem módosítható';
    if (label) {
      button.textContent = label;
    }
  };

  const fetchJson = async (url, options = {}) => {
    const response = await fetch(url, { credentials: 'same-origin', ...options });
    if (!response.ok) throw new Error('Szerver hiba');
    return response.json();
  };

  const setMessage = (type, text) => {
    if (!dom.adminMessage) return;
    if (!type || !text) {
      dom.adminMessage.hidden = true;
      dom.adminMessage.textContent = '';
      dom.adminMessage.className = 'admin-message';
      return;
    }
    dom.adminMessage.hidden = false;
    dom.adminMessage.textContent = text;
    dom.adminMessage.className = `admin-message ${type}`;
  };

  async function loadUsers(showLoader = true, clearMessage = false) {
    if (!dom.tableBody) return;

    if (showLoader) {
      dom.tableBody.innerHTML = '<tr><td colspan="5" class="loading-row">Adatok frissítése...</td></tr>';
    }

    try {
      const data = await fetchJson('php/admin_users.php');
      if (!data.success) throw new Error('Nincs jogosultság vagy hiba történt');

      state.users = data.users ?? [];
      renderUsers();
      updateStats();
      if (clearMessage) setMessage();
    } catch (error) {
      console.error(error);
      setMessage('error', 'Nem sikerült betölteni az adatokat.');
      dom.tableBody.innerHTML = '<tr><td colspan="5" class="loading-row">Hiba történt a lekérés során.</td></tr>';
    }
  }

  function renderUsers() {
    if (!dom.tableBody || !dom.rowTemplate || !dom.searchInput) return;

    const query = dom.searchInput.value.trim().toLowerCase();
    const filtered = state.users
      .filter(user => filterByStatus(user))
      .filter(user => filterBySearch(user, query));

    if (!filtered.length) {
      dom.tableBody.innerHTML = '<tr><td colspan="5" class="loading-row">Nincs megjeleníthető felhasználó.</td></tr>';
      return;
    }

    const fragment = document.createDocumentFragment();
    filtered.forEach(user => fragment.appendChild(buildRow(user)));
    dom.tableBody.innerHTML = '';
    dom.tableBody.appendChild(fragment);
  }

  function buildRow(user) {
    const clone = dom.rowTemplate.content.cloneNode(true);
    const isProtected = Boolean(user.is_admin);
    const userName = clone.querySelector('.user-name');
    const userId = clone.querySelector('.user-id');

    // Add avatar image to user-name
    if (user.avatar) {
      const avatarImg = document.createElement('img');
      avatarImg.src = `uploads/avatars/${user.avatar}`;
      avatarImg.alt = `${user.username} avatar`;
      avatarImg.className = 'user-avatar';
      avatarImg.style.width = '32px';
      avatarImg.style.height = '32px';
      avatarImg.style.borderRadius = '50%';
      avatarImg.style.marginRight = '0.5rem';
      userName.appendChild(avatarImg);
    }

    userName.appendChild(document.createTextNode(user.username));
    userId.textContent = isProtected ? `#${user.id} · Admin` : `#${user.id}`;
    clone.querySelector('.user-email').textContent = user.email;
    clone.querySelector('.user-last-active').textContent = formatLastActive(user.last_active);

    const statusPill = clone.querySelector('.status-pill');
    const onlineState = user.online ? 'true' : 'false';
    statusPill.textContent = `${LABELS.status[user.status] ?? user.status} · ${LABELS.online[onlineState]}`;
    statusPill.classList.toggle('online', user.online);
    statusPill.classList.toggle('offline', !user.online);
    statusPill.classList.toggle('disabled', user.status === 'disabled');
    if (isProtected) {
      statusPill.textContent += ' · Admin';
    }

    const editBtn = clone.querySelector('.edit-btn');
    if (isProtected) {
      disableActionButton(editBtn, 'Szerkesztés');
    } else {
      editBtn.addEventListener('click', () => openModal(user));
    }

    const toggleBtn = clone.querySelector('.toggle-btn');
    if (isProtected) {
      disableActionButton(toggleBtn, 'Védett');
    } else {
      toggleBtn.textContent = user.status === 'disabled' ? 'Feloldás' : 'Letiltás';
      toggleBtn.addEventListener('click', () => toggleStatus(user));
    }

    const deleteBtn = clone.querySelector('.delete-btn');
    if (isProtected) {
      disableActionButton(deleteBtn, 'Tiltott');
    } else {
      deleteBtn.addEventListener('click', () => deleteUser(user));
    }

    return clone;
  }

  function filterByStatus(user) {
    if (state.filter === 'online') return user.status === 'active' && user.online;
    if (state.filter === 'offline') return user.status === 'active' && !user.online;
    if (state.filter === 'disabled') return user.status === 'disabled';
    return true;
  }

  function filterBySearch(user, query) {
    if (!query) return true;
    return user.username.toLowerCase().includes(query) || user.email.toLowerCase().includes(query);
  }

  function formatLastActive(timestamp) {
    if (!timestamp) return 'Nincs adat';
    const date = new Date(timestamp.replace(' ', 'T'));
    return Number.isNaN(date.getTime()) ? timestamp : date.toLocaleString('hu-HU', { hour12: false });
  }

  function updateStats() {
    const total = state.users.length;
    const blocked = state.users.filter(user => user.status === 'disabled').length;
    const online = state.users.filter(user => user.status === 'active' && user.online).length;
    const active = total - blocked;

    setStat('total', total);
    setStat('blocked', blocked);
    setStat('active', active);
    setStat('online', online);

    updateToplist();
    updateChart(online);
  }

  function setStat(key, value) {
    dom.stats[key]?.textContent = value.toString();
  }

  function updateToplist() {
    if (!dom.toplist) return;

    const onlineUsers = state.users
      .filter(user => user.online && user.online_time)
      .sort((a, b) => {
        // Sort by online time descending (assuming format HH:MM)
        const timeA = a.online_time.split(':').map(Number);
        const timeB = b.online_time.split(':').map(Number);
        const minutesA = timeA[0] * 60 + timeA[1];
        const minutesB = timeB[0] * 60 + timeB[1];
        return minutesB - minutesA;
      })
      .slice(0, 10); // Top 10

    dom.toplist.innerHTML = onlineUsers.map(user => {
      const avatarHtml = user.avatar ? `<img src="uploads/avatars/${user.avatar}" alt="${user.username} avatar" style="width: 24px; height: 24px; border-radius: 50%; margin-right: 0.5rem;">` : '';
      return `<li><span>${avatarHtml}${user.username}</span><span>${user.online_time}</span></li>`;
    }).join('');
  }

  function updateChart(currentOnline) {
    if (!dom.chartCanvas) return;

    const now = new Date();
    const timeLabel = now.toLocaleTimeString('hu-HU', { hour12: false });

    state.chartData.labels.push(timeLabel);
    state.chartData.data.push(currentOnline);

    // Keep only last 60 points (10 min if 10s intervals)
    if (state.chartData.labels.length > 60) {
      state.chartData.labels.shift();
      state.chartData.data.shift();
    }

    if (!state.chart) {
      state.chart = new Chart(dom.chartCanvas, {
        type: 'line',
        data: {
          labels: state.chartData.labels,
          datasets: [{
            label: 'Online felhasználók',
            data: state.chartData.data,
            borderColor: 'var(--accent)',
            backgroundColor: 'rgba(244, 185, 66, 0.1)',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                color: 'var(--text-muted)'
              },
              grid: {
                color: 'var(--border)'
              }
            },
            x: {
              ticks: {
                color: 'var(--text-muted)'
              },
              grid: {
                color: 'var(--border)'
              }
            }
          },
          plugins: {
            legend: {
              labels: {
                color: 'var(--text-main)'
              }
            }
          }
        }
      });
    } else {
      state.chart.update();
    }
  }

  function openModal(user) {
    if (user.is_admin) {
      setMessage('error', 'Admin fiókok nem módosíthatók.');
      return;
    }
    if (!dom.modal || !dom.editForm) return;
    dom.modal.classList.add('active');
    dom.modal.setAttribute('aria-hidden', 'false');
    dom.editForm.reset();
    dom.editForm.user_id.value = user.id;
    dom.editForm.username.value = user.username;
    dom.editForm.email.value = user.email;
    dom.editForm.password.value = '';
    dom.editForm.username.focus();
  }

  function closeModal() {
    if (!dom.modal) return;
    dom.modal.classList.remove('active');
    dom.modal.setAttribute('aria-hidden', 'true');
  }

  async function toggleStatus(user) {
    if (user.is_admin) {
      setMessage('error', 'Admin fiókok nem módosíthatók.');
      return;
    }
    const status = user.status === 'disabled' ? 'active' : 'disabled';
    const message = status === 'disabled' ? 'le akarod tiltani' : 'engedélyezni szeretnéd';

    if (!window.confirm(`Biztos, hogy ${message} ${user.username} felhasználót?`)) return;
    await submitAction({ action: 'update_status', user_id: user.id, status }, `${user.username} státusza frissítve.`);
  }

  async function deleteUser(user) {
    if (user.is_admin) {
      setMessage('error', 'Admin fiókok nem törölhetők.');
      return;
    }
    if (!window.confirm(`Végleg törölni szeretnéd ${user.username} felhasználót? Ez nem vonható vissza.`)) return;
    await submitAction({ action: 'delete_user', user_id: user.id }, `${user.username} törölve.`);
  }

  async function submitAction(payload, successMessage) {
    try {
      const formData = payload instanceof FormData ? payload : new FormData();
      if (!(payload instanceof FormData)) {
        Object.entries(payload).forEach(([key, value]) => formData.append(key, value));
      }
      const data = await fetchJson('php/admin_users.php', { method: 'POST', body: formData });
      if (!data.success) throw new Error(data.error || 'Ismeretlen hiba');

      setMessage('success', successMessage);
      await loadUsers(false);
    } catch (error) {
      console.error(error);
      setMessage('error', 'A művelet nem sikerült.');
    }
  }

  function setupFilters() {
    if (!dom.filters.length) return;

    dom.filters.forEach(button => {
      button.addEventListener('click', event => {
        dom.filters.forEach(btn => btn.classList.remove('active'));
        event.currentTarget.classList.add('active');
        state.filter = event.currentTarget.dataset.filter ?? 'all';
        renderUsers();
      });
    });
  }

  function setupSearch() {
    dom.searchInput?.addEventListener('input', renderUsers);
  }

  function setupModal() {
    dom.modal?.addEventListener('click', event => {
      if (event.target === dom.modal) closeModal();
    });
    dom.modalCloseBtn?.addEventListener('click', closeModal);
    dom.cancelModalBtn?.addEventListener('click', closeModal);

    dom.editForm?.addEventListener('submit', async event => {
      event.preventDefault();
      const formData = new FormData(dom.editForm);
      const password = (formData.get('password') || '').toString();

      if (password && password.length < MIN_PASSWORD) {
        setMessage('error', `A jelszó legyen legalább ${MIN_PASSWORD} karakter.`);
        return;
      }

      formData.append('action', 'update_profile');
      await submitAction(formData, 'Felhasználói adatok frissítve.');
      closeModal();
    });
  }

  function scheduleAutoRefresh() {
    clearInterval(state.refreshTimer);
    state.refreshTimer = setInterval(() => loadUsers(false), 10000);
  }

  function startActivityPing() {
    const endpoint = 'php/update_activity.php';
    const ping = () => {
      fetch(endpoint, { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    };
    ping();
    setInterval(ping, 60000);
  }

  function init() {
    setupFilters();
    setupSearch();
    setupModal();
    loadUsers(true, true);
    scheduleAutoRefresh();
    startActivityPing();

    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) loadUsers(false);
    });
  }

  init();
})();
