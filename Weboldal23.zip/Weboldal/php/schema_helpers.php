<?php
declare(strict_types=1);

if (!defined('DB_NAME')) {
    throw new RuntimeException('DB constants must be defined before loading schema_helpers.');
}

/**
 * Ellenőrzi, hogy létezik-e a users táblában a megadott oszlop.
 */
function usersColumnExists(mysqli $db, string $column): bool
{
    static $cache = [];
    if (array_key_exists($column, $cache)) {
        return $cache[$column];
    }

    $schema = DB_NAME;
    $stmt = $db->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = "users" AND COLUMN_NAME = ? LIMIT 1');
    $stmt->bind_param('ss', $schema, $column);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();

    $cache[$column] = $exists;
    return $exists;
}

/**
 * Biztosítja, hogy létezzen a megadott oszlop, szükség esetén létrehozza.
 */
function ensureUsersColumn(mysqli $db, string $column, string $definition): void
{
    if (usersColumnExists($db, $column)) {
        return;
    }

    $db->query("ALTER TABLE users ADD COLUMN {$column} {$definition}");
}

function tableExists(mysqli $db, string $table): bool
{
    static $cache = [];
    if (array_key_exists($table, $cache)) {
        return $cache[$table];
    }

    $schema = DB_NAME;
    $stmt = $db->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? LIMIT 1');
    $stmt->bind_param('ss', $schema, $table);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();

    $cache[$table] = $exists;
    return $exists;
}

function columnExists(mysqli $db, string $table, string $column): bool
{
    static $cache = [];
    $key = "{$table}.{$column}";
    if (array_key_exists($key, $cache)) {
        return $cache[$key];
    }

    $schema = DB_NAME;
    $stmt = $db->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1');
    $stmt->bind_param('sss', $schema, $table, $column);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();

    $cache[$key] = $exists;
    return $exists;
}

function ensureAppSchema(mysqli $db): void
{
    ensureUsersColumn($db, 'first_name', 'VARCHAR(100) DEFAULT NULL');
    ensureUsersColumn($db, 'last_name', 'VARCHAR(100) DEFAULT NULL');
    ensureUsersColumn($db, 'chat_enabled', 'TINYINT(1) NOT NULL DEFAULT 1');
    ensureUsersColumn($db, 'is_admin', 'TINYINT(1) NOT NULL DEFAULT 0');
    ensureUsersColumn($db, 'account_status', "ENUM('active','disabled') NOT NULL DEFAULT 'active'");
    ensureUsersColumn($db, 'last_active', 'DATETIME NULL DEFAULT NULL');
    ensureUsersColumn($db, 'last_login', 'DATETIME NULL DEFAULT NULL');
    ensureUsersColumn($db, 'avatar', 'VARCHAR(255) DEFAULT NULL');
    ensureUsersColumn($db, 'bio', 'TEXT DEFAULT NULL');

    if (!tableExists($db, 'friends')) {
        $db->query("CREATE TABLE friends (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            friend_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY unique_friendship (user_id, friend_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    if (!tableExists($db, 'friend_requests')) {
        $db->query("CREATE TABLE friend_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            status ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY unique_request (sender_id, receiver_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }

    if (!tableExists($db, 'messages')) {
        $db->query("CREATE TABLE messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NULL DEFAULT NULL,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_conversation (sender_id, receiver_id),
            INDEX idx_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
}

if (!function_exists('ensure_app_schema')) {
    function ensure_app_schema(mysqli $db): void
    {
        ensureAppSchema($db);
    }
}
