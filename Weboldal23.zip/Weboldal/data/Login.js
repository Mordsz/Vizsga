document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const messageBox = document.getElementById('error-message');
  const passwordField = document.getElementById('passwordField');
  const togglePassword = document.getElementById('togglePassword');

  if (loginForm && messageBox) {
    loginForm.addEventListener('submit', event => handleLogin(event, loginForm, messageBox));
  }

  togglePassword?.addEventListener('click', event => {
    event.preventDefault();
    if (!passwordField) return;
    passwordField.type = passwordField.type === 'password' ? 'text' : 'password';
  });
});

async function handleLogin(event, form, messageBox) {
  event.preventDefault();

  if (window.location.protocol === 'file:') {
    showLoginError(messageBox, 'file_protocol');
    return;
  }

  try {
    const response = await fetch('php/login_process.php', {
      method: 'POST',
      body: new FormData(form),
      credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    });

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (parseError) {
      throw new Error(`Nem JSON válasz: ${response.status} ${response.statusText}`);
    }

    if (!response.ok) {
      showLoginError(messageBox, data.error || 'server_error');
      return;
    }

    if (data.success) {
      window.location.href = 'main.php';
      return;
    }

    showLoginError(messageBox, data.error || 'network');
  } catch (error) {
    console.error('Login hiba:', error);
    showLoginError(messageBox, 'network');
  }
}

function showLoginError(box, code) {
  const messages = {
    invalid_credentials: 'Helytelen felhasználónév vagy jelszó.',
    missing_fields: 'Mindkét mező kitöltése kötelező.',
    invalid_method: 'Hiba történt a feldolgozás során.',
    server_error: 'Szerverhiba történt, próbáld újra később.',
    account_disabled: 'A fiók jelenleg le van tiltva.',
    file_protocol: 'A weboldalt helyi szerveren kell futtatni, ne fájlként nyisd meg.',
    network: 'Váratlan hiba történt, próbáld meg később.'
  };

  box.textContent = messages[code] || 'Ismeretlen hiba történt.';
  box.style.display = 'block';
}