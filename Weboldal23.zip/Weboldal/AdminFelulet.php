﻿<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header('Location: main.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - Felület</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
  <header class="admin-header">
    <div class="admin-brand">
      <div class="brand-pill">Admin</div>
      <div>
        <h1>Admin Felület</h1>
        <p>Ez az admin felület csak admin joggal érhető el.</p>
      </div>
    </div>
    <div class="admin-actions">
      <span class="session-user">👤 <?= htmlspecialchars($_SESSION['user'] ?? 'Admin') ?></span>
      <a class="ghost-btn" href="main.php">Vissza</a>
      <form action="php/logout.php" method="POST">
        <button type="submit" class="ghost-btn danger">Kijelentkezés</button>
      </form>
    </div>
  </header>

  <main class="admin-main">
    <section>
      <h2>Admin Felület</h2>
      <p>Itt lesznek az admin funkciók később.</p>
    </section>
  </main>
</body>
</html><?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header('Location: main.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - Felhasználók kezelése</title>
  <link rel="stylesheet" href="assets/style.css">
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
  <header class="admin-header">
    <div class="admin-brand">
      <div class="brand-pill">Admin</div>
      <div>
        <h1>Felhasználókezelés</h1>
        <p>Ez az admin felület csak admin joggal érhető el.</p>
      </div>
    </div>
    <div class="admin-actions">
      <span class="session-user">👤 <?= htmlspecialchars($_SESSION['user'] ?? 'Admin') ?></span>
      <a class="ghost-btn" href="main.php">Vissza</a>
      <form action="php/logout.php" method="POST">
        <button type="submit" class="ghost-btn danger">Kijelentkezés</button>
      </form>
    </div>
  </header>

  <main class="admin-main">
    <section id="notificationSection" class="notification-banner" aria-live="polite" hidden>
      <div class="notification-content">
        <div class="notification-text">
          <strong id="registrationTitle">Új regisztráció történt!</strong>
          <p id="registrationMessage">Az új felhasználó neve: <span id="registrationName"></span></p>
        </div>
        <button type="button" class="notification-close" id="closeNotification">×</button>
      </div>
    </section>

    <section class="stats-grid" aria-live="polite">
      <article class="stat-card">
        <p>Összes felhasználó</p>
        <strong id="totalUsers">0</strong>
      </article>
      <article class="stat-card">
        <p>Online</p>
        <strong id="onlineUsers">0</strong>
      </article>
      <article class="stat-card">
        <p>Letiltva</p>
        <strong id="blockedUsers">0</strong>
      </article>
      <article class="stat-card">
        <p>Adminok</p>
        <strong id="adminUsers">0</strong>
      </article>
    </section>

    <section class="table-card">
      <div class="table-card__head">
        <div>
          <h2>Regisztrált felhasználók</h2>
          <p>Itt törölheted, tilthatod, chatből letilthatod és adminná teheted a felhasználókat.</p>
        </div>
        <div class="filters">
          <button class="filter-btn active" data-filter="all">Összes</button>
          <button class="filter-btn" data-filter="active">Aktív</button>
          <button class="filter-btn" data-filter="offline">Offline</button>
          <button class="filter-btn" data-filter="disabled">Letiltva</button>
        </div>
      </div>

      <div class="table-tools">
        <input type="search" id="userSearch" placeholder="Keresés név vagy email alapján...">
        <div id="adminMessage" class="admin-message" role="status" hidden></div>
      </div>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Felhasználó</th>
              <th>Email</th>
              <th>Státusz</th>
              <th>Chat</th>
              <th>Regisztrált</th>
              <th>Műveletek</th>
            </tr>
          </thead>
          <tbody id="userTableBody">
            <tr>
              <td colspan="6" class="loading-row">Adatok betöltése...</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </main>

  <template id="userRowTemplate">
    <tr>
      <td class="user-col">
        <p class="user-name"></p>
        <span class="user-id"></span>
      </td>
      <td class="user-email"></td>
      <td>
        <span class="status-pill"></span>
      </td>
      <td class="chat-status"></td>
      <td class="user-created"></td>
      <td class="actions">
        <button class="ghost-btn toggle-btn" type="button"></button>
        <button class="ghost-btn chat-btn" type="button"></button>
        <button class="ghost-btn admin-btn" type="button"></button>
        <button class="ghost-btn danger delete-btn" type="button">Törlés</button>
      </td>
    </tr>
  </template>

  <script src="data/Admin.js" defer></script>
</body>
</html>
