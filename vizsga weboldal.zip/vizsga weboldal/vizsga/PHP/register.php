<?php
// php/register.php
require_once __DIR__ . '/db_connect.php';
include __DIR__ . '/db_connect.php';


// Egyszerű helper a válaszhoz
function respond($msg) {
    echo htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond('Érvénytelen kérés.');
}

// Bemenet szűrése
$keresztnev     = trim($_POST['keresztnev'] ?? '');
$vezeteknev     = trim($_POST['vezeteknev'] ?? '');
$email          = trim($_POST['email'] ?? '');
$felhasznalonev = trim($_POST['felhasznalonev'] ?? '');
$orszag         = trim($_POST['orszag'] ?? '');
$jelszo         = $_POST['jelszo'] ?? '';
$telefonszam    = trim($_POST['telefonszam'] ?? '');

// Alap validálás
if ($keresztnev === '' || $vezeteknev === '' || $email === '' || $felhasznalonev === '' || $jelszo === '') {
    respond('Kérlek töltsd ki a kötelező mezőket.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond('Az email formátuma érvénytelen.');
}
if (strlen($jelszo) < 8) {
    respond('A jelszó legyen legalább 8 karakter.');
}

// Duplikáció ellenőrzése (email vagy felhasználónév már foglalt-e)
$checkSql = "SELECT id FROM Felhasznalo WHERE Email = ? OR FelhasznaloNev = ? LIMIT 1";
$checkStmt = $mysqli->prepare($checkSql);
$checkStmt->bind_param('ss', $email, $felhasznalonev);
$checkStmt->execute();
$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {
    $checkStmt->close();
    respond('Az email vagy felhasználónév már foglalt.');
}
$checkStmt->close();

// Jelszó hashelés
$hash = password_hash($jelszo, PASSWORD_DEFAULT);
if ($hash === false) {
    respond('Hiba történt a jelszó feldolgozásakor.');
}

// Mentés
$insertSql = "INSERT INTO Felhasznalo 
    (Keresztnev, Vezeteknev, Email, FelhasznaloNev, Orszag, Jelszo, Telefonszam, ProfilKep) 
    VALUES (?, ?, ?, ?, ?, ?, ?, NULL)";
$insertStmt = $mysqli->prepare($insertSql);
$insertStmt->bind_param('sssssss',
    $keresztnev, $vezeteknev, $email, $felhasznalonev, $orszag, $hash, $telefonszam
);

if ($insertStmt->execute()) {
    respond('Sikeres regisztráció! Most már bejelentkezhetsz.');
} else {
    // Ha UNIQUE ütközés lenne, ide is beérkezhet, de fent már szűrtük
    respond('Mentési hiba: ' . $insertStmt->error);
}
