<?php
// php/db_connect.php
$DB_HOST = 'mysql.rackhost.hu';
$DB_NAME = 'c93778tidesofenvy';
$DB_USER = 'c93778CsipCsip';
$DB_PASS = 'DonerKebab69';

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli->connect_error) {
    die('Adatbázis kapcsolódási hiba: ' . $mysqli->connect_error);
}

$mysqli->set_charset('utf8mb4');
