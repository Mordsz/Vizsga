<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Főoldal</title>
<link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>

<body>

<div class="nav">
    <div class="nav-logo"></div>
    <div class="nav-title">TidesOfEnvy</div>
    <div class="nav-user">
      <div class="profile-pic"></div>
        </div>
      <div class="username"><?= htmlspecialchars($_SESSION["user"]) ?></div>
</div>

<main class="main-content">
  <h2>Üdv a főoldalon!</h2>
  
<button id="DownloadBTN"><a href="https://tidesofenvy.hu//downloads/Launcher1.0.zip" download>Letöltés</a></button>

</main>


<script src="data/Fooldal.js"></script>
</body>
</html>
