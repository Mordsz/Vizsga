<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

require_method('POST');
$auth = require_auth();

try {
    $db = db();
    ensure_user_columns([
        ['name' => 'last_active', 'definition' => 'DATETIME NULL DEFAULT NULL']
    ]);

    $stmt = $db->prepare('UPDATE users SET last_active = NOW() WHERE id = ?');
    $stmt->bind_param('i', $auth['user_id']);
    $stmt->execute();
    $stmt->close();

    json_success();
} catch (Throwable $exception) {
    error_log('Activity ping error: ' . $exception->getMessage());
    json_error('server_error', 'Szerverhiba történt', 500);
}
