﻿using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using System.Diagnostics;

namespace Launcher
{
 public partial class MainWindow : Window
 {
 private const string ConfigFile = "launcher.config";

 public MainWindow()
 {
 InitializeComponent();
 LoadSettings();
 }

 private T Get<T>(string name) where T : class
 {
 return this.FindName(name) as T;
 }

 private void btnBrowse_Click(object sender, RoutedEventArgs e)
 {
 var dlg = new OpenFileDialog();
 dlg.Filter = "Executable|*.exe|All files|*.*";
 dlg.Title = "Select game executable";
 if (dlg.ShowDialog() == true)
 {
 var txtExePath = Get<System.Windows.Controls.TextBox>("txtExePath");
 var txtStatus = Get<System.Windows.Controls.TextBlock>("txtStatus");
 if (txtExePath != null)
 txtExePath.Text = dlg.FileName;
 if (txtStatus != null)
 txtStatus.Text = "Game executable set.";
 SaveSettings();
 }
 }

 private void btnClear_Click(object sender, RoutedEventArgs e)
 {
 var txtExePath = Get<System.Windows.Controls.TextBox>("txtExePath");
 var txtStatus = Get<System.Windows.Controls.TextBlock>("txtStatus");
 if (txtExePath == null)
 return;
 txtExePath.Text = string.Empty;
 if (txtStatus != null) txtStatus.Text = "Selection cleared.";
 SaveSettings();
 }

 private void btnStart_Click(object sender, RoutedEventArgs e)
 {
 var txtExePath = Get<System.Windows.Controls.TextBox>("txtExePath");
 var txtStatus = Get<System.Windows.Controls.TextBlock>("txtStatus");
 if (txtExePath == null)
 {
 MessageBox.Show("UI not initialized.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
 return;
 }
 var path = txtExePath.Text;
 if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
 {
 MessageBox.Show("Please select the game's executable first.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
 return;
 }

 try
 {
 var startInfo = new ProcessStartInfo(path)
 {
 WorkingDirectory = Path.GetDirectoryName(path)
 };
 Process.Start(startInfo);
 if (txtStatus != null) txtStatus.Text = "Game started.";
 SaveSettings();
 }
 catch (Exception ex)
 {
 MessageBox.Show("Failed to start game: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
 if (txtStatus != null) txtStatus.Text = "Failed to start game.";
 }
 }

 private void LoadSettings()
 {
 try
 {
 if (!File.Exists(ConfigFile))
 return;
 var lines = File.ReadAllLines(ConfigFile);
 var txtExePath = Get<System.Windows.Controls.TextBox>("txtExePath");
 var txtStatus = Get<System.Windows.Controls.TextBlock>("txtStatus");
 foreach (var line in lines)
 {
 if (line.StartsWith("exe=") && txtExePath != null)
 txtExePath.Text = line.Substring(4).Trim();
 }
 if (txtStatus != null) txtStatus.Text = "Settings loaded.";
 }
 catch
 {
 // ignore
 }
 }

 private void SaveSettings()
 {
 try
 {
 var txtExePath = Get<System.Windows.Controls.TextBox>("txtExePath");
 var txtStatus = Get<System.Windows.Controls.TextBlock>("txtStatus");
 var lines = new System.Collections.Generic.List<string>();
 lines.Add("exe=" + (txtExePath?.Text ?? string.Empty));
 File.WriteAllLines(ConfigFile, lines);
 if (txtStatus != null) txtStatus.Text = "Settings saved.";
 }
 catch
 {
 // ignore
 }
 }
 }
}
