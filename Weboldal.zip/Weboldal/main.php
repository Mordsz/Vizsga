<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.html");
    exit;
}
?>



<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Főoldal</title>
<link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>

<body>

<div class="nav">
    <div class="nav-logo"></div>
    <div class="nav-title">TidesOfEnvy</div>
    <div class="nav-user">
      <div class="profile-pic" id="profilePic" style="cursor: pointer; background-size: cover; background-position: center;"></div>
      <div class="username"><?= htmlspecialchars($_SESSION["user"]) ?></div>
      <div class="profile-menu">
        <button class="profile-menu-btn" id="profileMenuBtn">Profil menü</button>
        <div class="profile-dropdown" id="profileDropdown">
          <a href="index.html">Kezdőoldal</a>
          <a href="login.html">Belépés</a>
          <a href="register.html">Regisztráció</a>
          <hr>
          <form action="php/logout.php" method="POST" style="margin: 0;">
            <button type="submit" class="dropdown-btn">Kijelentkezés</button>
          </form>
          <form action="php/delete_account.php" method="POST" style="margin: 0;">
            <button type="submit" class="dropdown-btn delete-btn" onclick="return confirm('Biztosan törlöd a profilodat? Ez nem vonható vissza!');">Profil törlése</button>
          </form>
        </div>
      </div>
    </div>
</div>

<main class="main-content">
  <h2>Üdv a főoldalon!</h2>
  
  <!-- Játék Galériája -->
  <section class="game-gallery-section">
    <h3>Játék Galériája</h3>
    
    <!-- Galériamegjelenítés -->
    <div class="gallery-container">
      <div class="gallery-viewer">
        <button class="gallery-nav-btn prev-btn" id="prevGalleryBtn">❮</button>
        <div class="gallery-main">
          <img id="mainGalleryImage" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='300'%3E%3Crect fill='%23423530' width='400' height='300'/%3E%3Ctext x='50%25' y='50%25' font-size='48' fill='%23a68a6b' text-anchor='middle' dy='.3em'%3E🎮 Képe 1%3C/text%3E%3C/svg%3E" alt="Játék képe" class="gallery-image-placeholder">
          <div id="galleryPlaceholder" class="gallery-placeholder"></div>
        </div>
        <button class="gallery-nav-btn next-btn" id="nextGalleryBtn">❯</button>
      </div>

      <!-- Képek ábráját (thumbnails) -->
      <div class="gallery-thumbnails" id="galleryThumbnails">
        <div class="thumbnail" data-index="0">
          <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='88' height='66'%3E%3Crect fill='%23423530' width='88' height='66'/%3E%3Ctext x='50%25' y='50%25' font-size='24' fill='%237B6B52' text-anchor='middle' dy='.3em'%3E1%3C/text%3E%3C/svg%3E" alt="Kép 1">
        </div>
        <div class="thumbnail" data-index="1">
          <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='88' height='66'%3E%3Crect fill='%23423530' width='88' height='66'/%3E%3Ctext x='50%25' y='50%25' font-size='24' fill='%237B6B52' text-anchor='middle' dy='.3em'%3E2%3C/text%3E%3C/svg%3E" alt="Kép 2">
        </div>
        <div class="thumbnail" data-index="2">
          <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='88' height='66'%3E%3Crect fill='%23423530' width='88' height='66'/%3E%3Ctext x='50%25' y='50%25' font-size='24' fill='%237B6B52' text-anchor='middle' dy='.3em'%3E3%3C/text%3E%3C/svg%3E" alt="Kép 3">
        </div>
        <div class="thumbnail" data-index="3">
          <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='88' height='66'%3E%3Crect fill='%23423530' width='88' height='66'/%3E%3Ctext x='50%25' y='50%25' font-size='24' fill='%237B6B52' text-anchor='middle' dy='.3em'%3E4%3C/text%3E%3C/svg%3E" alt="Kép 4">
        </div>
        <div class="thumbnail" data-index="4">
          <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='88' height='66'%3E%3Crect fill='%23423530' width='88' height='66'/%3E%3Ctext x='50%25' y='50%25' font-size='24' fill='%237B6B52' text-anchor='middle' dy='.3em'%3E5%3C/text%3E%3C/svg%3E" alt="Kép 5">
        </div>
        <div class="thumbnail" data-index="5">
          <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='88' height='66'%3E%3Crect fill='%23423530' width='88' height='66'/%3E%3Ctext x='50%25' y='50%25' font-size='24' fill='%237B6B52' text-anchor='middle' dy='.3em'%3E6%3C/text%3E%3C/svg%3E" alt="Kép 6">
        </div>
      </div>

      <!-- Képzámlálók -->
      <div class="gallery-counter">
        <span id="currentImageIndex">1</span> / <span id="totalImages">6</span>
      </div>
    </div>

    <!-- Játék Leírása -->
    <div class="game-description">
      <h4>A Játékról</h4>
      <p>Ez a leírás szekció hamarosan feltöltésre kerül!</p>
    </div>
  </section>

  <!-- Letöltés gomb -->
  <br>
  <button id="DownloadBTN">
    <div class="progress-bar"></div>
    <a href="https://tidesofenvy.hu//downloads/Launcher1.0.zip" download>Letöltés</a>
  </button>

</main>

<!-- Profil Edit Oldal -->
<div id="profileModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h2>Profilom szerkesztése</h2>
      <span class="close" id="closeProfileModal">&times;</span>
    </div>
    
    <form id="profileEditForm" enctype="multipart/form-data">
      <!-- Avatar Upload -->
      <div class="form-section avatar-section">
        <h3>Avatar - Profilkép</h3>
        <div class="avatar-container">
          <div class="avatar-preview" id="avatarPreview"></div>
          <div class="avatar-info">
            <p>Kattints a képre vagy az alábbi gombra a feltöltéshez</p>
            <label for="avatarInput" class="upload-btn">Kiválasztás</label>
            <input type="file" id="avatarInput" name="avatar" accept="image/*" style="display: none;">
            <small>PNG, JPG, GIF | Max 5MB</small>
          </div>
        </div>
      </div>

      <!-- Személyes adatok -->
      <div class="form-section">
        <h3>Személyes adatok</h3>
        <input type="text" id="firstName" name="first_name" placeholder="Keresztnév">
        <input type="text" id="lastName" name="last_name" placeholder="Vezetéknév">
        <textarea id="profileBio" name="bio" placeholder="Rólad (bio)"></textarea>
      </div>

      <!-- Email -->
      <div class="form-section">
        <h3>Email cím</h3>
        <input type="email" id="email" name="email" placeholder="Email cím">
        <small>Az email módosításához jelszódat meg kell adnod!</small>
        <div class="password-wrapper">
          <input type="password" id="emailPassword" name="email_password" placeholder="Jelszó az email módosításához">
          <button type="button" class="toggle-password" id="toggleEmailPassword">👁️‍🗨️</button>
        </div>
      </div>

      <!-- Jelszó módosítás -->
      <div class="form-section">
        <h3>Jelszó módosítása</h3>
        <div class="password-wrapper">
          <input type="password" id="currentPassword" name="current_password" placeholder="Jelenlegi jelszó">
          <button type="button" class="toggle-password" id="toggleCurrentPassword">👁️‍🗨️</button>
        </div>
        <div class="password-wrapper">
          <input type="password" id="newPassword" name="new_password" placeholder="Új jelszó">
          <button type="button" class="toggle-password" id="toggleNewPassword">👁️‍🗨️</button>
        </div>
        <div class="password-wrapper">
          <input type="password" id="confirmPassword" name="confirm_password" placeholder="Új jelszó megerősítése">
          <button type="button" class="toggle-password" id="toggleConfirmPassword">👁️‍🗨️</button>
        </div>
        <small>Hagyj üresen, ha nem szeretnéd módosítani!</small>
      </div>

      <div id="profileMessage" class="message" style="display: none;"></div>

      <button type="submit" class="modal-submit-btn">Mentés</button>
    </form>
  </div>
</div>

<script src="data/Fooldal.js"></script>
</body>
</html>
