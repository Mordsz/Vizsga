// Background Music Control
document.addEventListener('DOMContentLoaded', function() {
    const audio = document.getElementById('backgroundMusic');
    const musicToggleBtn = document.getElementById('musicToggleBtn');
    const volumeSlider = document.getElementById('volumeSlider');
    const volumeDisplay = document.getElementById('volumeDisplay');
    
    if (!audio || !musicToggleBtn || !volumeSlider) {
        return;
    }
    
    // Kezdetben a zene némítva van (felhasználó interakció nélkül nem játszható le)
    let isMuted = true;
    
    // Frissítsd a gomb megjelenését az audio állapota alapján
    function updateButtonState() {
        if (isMuted || audio.paused) {
            musicToggleBtn.classList.add('muted');
            musicToggleBtn.textContent = '🔇';
            musicToggleBtn.title = 'Zene bekapcsolása';
        } else {
            musicToggleBtn.classList.remove('muted');
            musicToggleBtn.textContent = '🔊';
            musicToggleBtn.title = 'Zene kikapcsolása';
        }
    }
    
    // Frissítsd a hangerő kijelzőt
    function updateVolumeDisplay() {
        const volume = volumeSlider.value;
        if (volumeDisplay) {
            volumeDisplay.textContent = volume + '%';
        }
    }
    
    // Hangerő beállítása a csúszkáról
    volumeSlider.addEventListener('input', function() {
        const volume = this.value / 100;
        audio.volume = volume;
        updateVolumeDisplay();
        
        // Ha a hangerő nagyobb, mint 0, akkor biztos, hogy nem némított
        if (volume > 0 && !isMuted && audio.paused) {
            audio.play().catch(error => {
                console.error('Audio playback failed:', error);
            });
        }
    });
    
    // Zene lejátszása/megállítása
    musicToggleBtn.addEventListener('click', function() {
        if (isMuted || audio.paused) {
            // Audio lejátszása
            const volume = volumeSlider.value / 100;
            audio.volume = volume;
            const playPromise = audio.play();
            
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    isMuted = false;
                    updateButtonState();
                }).catch(error => {
                    console.error('Audio playback failed:', error);
                    isMuted = true;
                    updateButtonState();
                });
            } else {
                isMuted = false;
                updateButtonState();
            }
        } else {
            // Audio szüneteltetése
            audio.pause();
            isMuted = true;
            updateButtonState();
        }
    });
    
    // Kezdeti gomb állapot és kijelző
    updateButtonState();
    updateVolumeDisplay();
    
    // Audio véghez elérése után, indítsa újra (loop-hoz)
    audio.addEventListener('ended', function() {
        if (!isMuted) {
            audio.currentTime = 0;
            audio.play();
        }
    });
});
