<?php
declare(strict_types=1);
header('Content-Type: application/json');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'invalid_method']);
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    echo json_encode(['success' => false, 'error' => 'missing_fields']);
    exit;
}

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    $stmt = $db->prepare('SELECT id, password FROM users WHERE username = ? LIMIT 1');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        echo json_encode(['success' => false, 'error' => 'invalid_credentials']);
        exit;
    }

    $stmt->bind_result($userId, $hashedPassword);
    $stmt->fetch();
    $stmt->close();
    $db->close();

    if (password_verify($password, $hashedPassword)) {
        session_start();
        $_SESSION['user'] = $username;
        $_SESSION['user_id'] = $userId;
        echo json_encode(['success' => true, 'username' => $username, 'user_id' => $userId]);
        exit;
    }

    echo json_encode(['success' => false, 'error' => 'invalid_credentials']);
} catch (mysqli_sql_exception $exception) {
    error_log('Login error: ' . $exception->getMessage());
    echo json_encode(['success' => false, 'error' => 'server_error']);}