<?php
/**
 * Database Migration Script
 * Ezt a fájlt csak egyszer kell futtatni az adatbázis frissítéséhez
 * Run this once: http://yourwebsite.hu/php/db_migration.php
 */

declare(strict_types=1);

require __DIR__ . '/config.php';

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    // Avatar oszlop hozzáadása, ha még nem létezik
    $checkAvatarStmt = $db->prepare("SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_NAME='users' AND COLUMN_NAME='avatar'");
    $checkAvatarStmt->execute();
    $checkAvatarStmt->store_result();

    if ($checkAvatarStmt->num_rows === 0) {
        $db->query("ALTER TABLE users ADD COLUMN avatar VARCHAR(255) DEFAULT NULL");
        echo "✓ Avatar column added<br>";
    } else {
        echo "✓ Avatar column already exists<br>";
    }
    $checkAvatarStmt->close();

    // Bio oszlop hozzáadása, ha még nem létezik
    $checkBioStmt = $db->prepare("SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_NAME='users' AND COLUMN_NAME='bio'");
    $checkBioStmt->execute();
    $checkBioStmt->store_result();

    if ($checkBioStmt->num_rows === 0) {
        $db->query("ALTER TABLE users ADD COLUMN bio TEXT DEFAULT NULL");
        echo "✓ Bio column added<br>";
    } else {
        echo "✓ Bio column already exists<br>";
    }
    $checkBioStmt->close();

    $db->close();
    echo "<br>Database migration completed successfully!<br>";
    echo "You can now delete this file.";

} catch (Exception $e) {
    echo "Migration error: " . $e->getMessage();
    error_log('Migration error: ' . $e->getMessage());
}
