// Simple client-side validation + password strength
console.log("REGI.JS BETÖLTÖTT");
const form = document.getElementById('regForm');
const pw = document.getElementById('password');
const confirmPw = document.getElementById('confirm');
const pwBar = document.getElementById('pwBar');
const submitBtn = document.getElementById('submitBtn');

// ✅ ÁLLÍTSD BE: a saját domained + helyes PHP végpont
// Példa: "https://sajatdomain.hu/api/register.php"
const API_URL = "https://tidesofenvy.hu/php/register.php";

function setHelper(name, msg, isError) {
  const el = document.querySelector(`.helper[data-for="${name}"]`);
  if (!el) return;
  el.textContent = msg || '';
  el.style.color = isError ? '#f97316' : '#94a3b8';
}

function strengthScore(s) {
  let score = 0;
  if (s.length >= 8) score += 1;
  if (/[A-Z]/.test(s)) score += 1;
  if (/[0-9]/.test(s)) score += 1;
  if (/[^A-Za-z0-9]/.test(s)) score += 1;
  return score; // 0..4
}

pw?.addEventListener('input', () => {
  const s = strengthScore(pw.value);
  const pct = (s / 4) * 100;

  if (pwBar) {
    pwBar.style.width = pct + '%';
    pwBar.className = '';
    if (s <= 1) pwBar.classList.add('pw-weak');
    else if (s === 2 || s === 3) pwBar.classList.add('pw-medium');
    else pwBar.classList.add('pw-strong');
  }

  if (pw.value.length < 8) {
    setHelper('password', 'A jelszónak legalább 8 karakter hosszúnak kell lennie.', true);
  } else {
    setHelper('password', '');
  }
});

function validate() {
  let ok = true;

  // built-in validity
  const fields = ['first', 'last', 'email', 'username', 'password', 'confirm'];
  fields.forEach(id => {
    const f = document.getElementById(id);
    if (!f) return;

    if (!f.checkValidity()) {
      setHelper(id, f.validationMessage || 'Kötelező mező', true);
      ok = false;
    } else {
      setHelper(id, '');
    }
  });

  // custom: password match
  if (pw && confirmPw && pw.value && confirmPw.value && pw.value !== confirmPw.value) {
    setHelper('confirm', 'A két jelszó nem egyezik.', true);
    ok = false;
  }

  // email simple pattern
  const emailEl = document.getElementById('email');
  if (emailEl?.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailEl.value)) {
    setHelper('email', 'Érvénytelen e-mail cím.', true);
    ok = false;
  }

  // disable submit while invalid
  if (submitBtn) submitBtn.disabled = !ok;

  return ok;
}

form?.addEventListener('input', validate);

form?.addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!validate()) return;

  submitBtn.disabled = true;
  const originalBtnText = submitBtn.textContent;
  submitBtn.textContent = 'Feldolgozás...';

  try {
    // ✅ Backendnek küldött adatok (kulcsnevek egyezzenek a PHP-val)
    const payload = {
      first_name: document.getElementById('first')?.value?.trim() || '',
      last_name: document.getElementById('last')?.value?.trim() || '',
      email: document.getElementById('email')?.value?.trim() || '',
      username: document.getElementById('username')?.value?.trim() || '',
      password: document.getElementById('password')?.value || '',
      country: document.getElementById('country')?.value?.trim() || null,
      phone: document.getElementById('phone')?.value?.trim() || null
    };

    // extra biztonság: üres kötelezők
    if (!payload.first_name || !payload.last_name || !payload.email || !payload.username || !payload.password) {
      throw new Error('Hiányzó kötelező mező(k).');
    }

    const response = await fetch(API_URL,  {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    let result = null;
    const text = await response.text();

    // próbáljuk JSON-ként olvasni; ha nem JSON, akkor is látjuk a választ
    try { result = JSON.parse(text); } catch { result = { raw: text }; }

    if (!response.ok) {
      // Hibák kezelése
      if (result && result.errors) {
        Object.keys(result.errors).forEach(key => {
          setHelper(key, result.errors[key], true);
        });
      } else if (result && result.error) {
        alert('Hiba: ' + result.error);
      } else {
        alert('Hiba: ' + (result?.raw || 'Ismeretlen hiba'));
      }
      throw new Error(result?.error || 'Regisztráció sikertelen');
    }

    // Sikeres regisztráció
    alert('Sikeres regisztráció! ' + (result?.message || 'Üdvözlünk!'));
    form.reset();
    if (pwBar) pwBar.style.width = '0%';

    // Átirányítás a főoldalra
    setTimeout(() => {
      window.location.href = '/Html/index.html';
    }, 1500);

  } catch (error) {
    console.error('Regisztráció hiba:', error);
    alert('Hiba történt: ' + error.message);
  } finally {
    submitBtn.textContent = originalBtnText || 'Regisztráció';
    submitBtn.disabled = false;
  }
});

// initial validation pass
validate();

// Profilkép előnézet (csak preview, nem upload)
const pfpInput = document.getElementById('pfpUpload');
const pfpPrevContainer = document.getElementById('pfpPreviewContainer');
const pfpPrev = document.getElementById('pfpPreview');

if (pfpInput) {
  pfpInput.addEventListener('change', () => {
    const file = pfpInput.files?.[0];
    if (!file) {
      if (pfpPrevContainer) pfpPrevContainer.style.display = 'none';
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      if (pfpPrev) pfpPrev.src = e.target.result;
      if (pfpPrevContainer) pfpPrevContainer.style.display = 'block';
    };
    reader.readAsDataURL(file);
  });
}