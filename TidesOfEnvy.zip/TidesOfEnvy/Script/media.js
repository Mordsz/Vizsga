// Lightbox funkció
document.querySelectorAll('.cards-grid .card img').forEach(img => {
  img.addEventListener('click', () => {
    let overlay = document.createElement('div');
    overlay.classList.add('lightbox-overlay');

    let lightboxImg = document.createElement('img');
    lightboxImg.src = img.src;
    overlay.appendChild(lightboxImg);

    let closeBtn = document.createElement('div');
    closeBtn.classList.add('lightbox-close');
    closeBtn.textContent = '×';
    overlay.appendChild(closeBtn);

    document.body.appendChild(overlay);

    overlay.classList.add('active');

    closeBtn.addEventListener('click', () => {
      overlay.classList.remove('active');
      setTimeout(() => overlay.remove(), 300);
    });

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) {
        overlay.classList.remove('active');
        setTimeout(() => overlay.remove(), 300);
      }
    });
  });
});
