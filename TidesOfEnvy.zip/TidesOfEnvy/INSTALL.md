# MySQL Regisztráció Integráció - ÚTMUTATÓ

## 📋 Szükséges Lépések

### 1. Adatbázis Beállítása
```
a) Nyisd meg a phpMyAdmin-t vagy MySQL CLI-t
b) Futtasd a `database-schema.sql` tartalmát
   - Ez létrehozza az `users` táblát az összes szükséges mezővel
```

### 2. Config Fájl Módosítása
**File:** `config.php`

Módosítsd az alábbi adatokat a saját MySQL credentials-eddel:
```php
define('DB_HOST', 'localhost');    // MySQL host (általában localhost, de lehet más)
define('DB_USER', 'root');          // A te MySQL felhasználóneved
define('DB_PASS', 'jelszó');        // A te MySQL jelszavad
define('DB_NAME', 'tidesofenvy');   // Az adatbázis neve
```

### 3. Fájlok Feltöltése a Webtárhelyre
Tölts fel FTP-n vagy file managerrel:
- `config.php` → gyökerbe
- `register.php` → gyökerbe
- `regi.js` → frissített verzió a Script mappában

### 4. Fájljogi Beállítások (CHMOD)
Néhány hosting azt igényli:
```
config.php:   644
register.php: 644
```

### 5. Tesztelés

**Helyi tesztelés:**
```bash
php -S localhost:8000
# majd menj ide: http://localhost:8000/Html/regi.html
```

**Tesztelési adatok:**
- Felhasználónév: legalább 3 karakter, csak [a-z0-9_]
- E-mail: valódi e-mail formátum
- Jelszó: minimum 8 karakter
- Jelszó erősség: zöld (ajánlott: szám + nagybetű + speciális karakter)

## 🔐 Biztonsági Jellemzők

✅ **Implementálva:**
- Jelszó BCrypt hash-eléssel van tárolva (nem plain text)
- UNIQUE email és username (duplikáció védelme)
- Server-side validáció (nem csak kliens-oldali!)
- SQL Injection защита (PDO prepared statements)
- Password confirmation check

## 📱 Frontend Integráció

A `regi.js` automatikusan:
1. Validálja az adatokat kliens-oldalon
2. POST-olja JSON-ban a `/register.php`-nek
3. Feldolgozza a hibákat és megjeleníti azokat
4. Sikeres regisztrációnál átirányít a főoldalra

## 🐛 Hibaelhárítás

**Ha "Adatbázis kapcsolati hiba" jönAssistant:**
- Ellenőrizd a `config.php`-ben az adatokat
- Bizonyosodj meg, hogy MySQL fut
- Ellenőrizd a MySQL felhasználónév/jelszó helyességét

**Ha "Felhasználónév már foglalt":**
- Normális! Az adatbázisban már létezik ez a felhasználónév

**Ha a form nem küld:**
- Nyisd meg az F12 konzolt, nézd meg az error messages
- Győződj meg róla, hogy `register.php` létezik a gyökérben

## 📊 Adatbázis Struktúra

```
users tábla:
- id (INT, PK, AUTO_INCREMENT)
- first_name (VARCHAR 50)
- last_name (VARCHAR 50)
- email (VARCHAR 120, UNIQUE)
- username (VARCHAR 30, UNIQUE)
- password (VARCHAR 255, bcrypt hash)
- country (VARCHAR 2, default: 'HU')
- phone (VARCHAR 20, nullable)
- profile_image (LONGBLOB, nullable)
- is_verified (BOOLEAN, default: false)
- created_at (TIMESTAMP, default: NOW())
- updated_at (TIMESTAMP, auto-update)
```

## 🚀 Következő Lépések (Opcionális)

1. **E-mail verifikáció**
   - Küldj verifikációs linket a regisztrációkor
   
2. **Bejelentkezés (Login)**
   - Jelszó ellenőrzés a `password_verify()` függvénnyel

3. **Profilkép Tárolás**
   - A `profile_image` mező már LONGBLOB, készen áll

4. **Jelszó Reset**
   - Token-alapú jelszó reset mechanizmus

## 📞 Támogatás

Ha bármilyen probléma adódik, ellenőrizd:
- MySQL credentials helyessége
- SQL syntax (`database-schema.sql`)
- PHP verzió kompatibilitás (7.2+)
- HTTPS (ha szükséges)
