<?php
$host = "mysql.rackhost.hu";
$db   = "c93778tidesofenvy";
$user = "c93778CsipCsip";
$pass = "DonerKebab69";
$charset = "utf8mb4";

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$db;charset=$charset",
        $user,
        $pass
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("DB hiba: " . $e->getMessage());
}