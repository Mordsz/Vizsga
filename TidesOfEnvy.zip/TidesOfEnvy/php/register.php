<?php
header("Content-Type: application/json; charset=utf-8");
require __DIR__ . "/config.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  http_response_code(405);
  echo json_encode(["success" => false, "error" => "Method not allowed"]);
  exit;
}

// JSON body beolvasás
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

if (!is_array($data)) {
  http_response_code(400);
  echo json_encode(["success" => false, "error" => "Invalid JSON"]);
  exit;
}

// Kötelező mezők (a DB oszlopneveidhez igazítva)
$first_name = trim($data["first_name"] ?? "");
$last_name  = trim($data["last_name"] ?? "");
$email      = trim($data["email"] ?? "");
$username   = trim($data["username"] ?? "");
$password   = (string)($data["password"] ?? "");

// Opcionális mezők
$country = trim($data["country"] ?? "");
$phone   = trim($data["phone"] ?? "");

// Validáció
$errors = [];

if ($first_name === "") $errors["first_name"] = "Kötelező.";
if ($last_name === "")  $errors["last_name"]  = "Kötelező.";
if ($email === "")      $errors["email"]      = "Kötelező.";
if ($username === "")   $errors["username"]   = "Kötelező.";
if ($password === "")   $errors["password"]   = "Kötelező.";

if ($email !== "" && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $errors["email"] = "Érvénytelen email.";
}

if ($password !== "" && strlen($password) < 8 ) {
  $errors["password"] = "Minimum 8 karakter.";
}

if (!empty($errors)) {
  http_response_code(422);
  echo json_encode(["success" => false, "errors" => $errors]);
  exit;
}

// Duplikáció ellenőrzés
$check = $pdo->prepare("SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1");
$check->execute([$email, $username]);
if ($check->fetch()) {
  http_response_code(409);
  echo json_encode(["success" => false, "error" => "Email vagy username már létezik."]);
  exit;
}

// Jelszó hash
$hash = password_hash($password, PASSWORD_DEFAULT);

// Beszúrás
$stmt = $pdo->prepare("
  INSERT INTO users
  (first_name, last_name, email, username, password, country, phone, created_at, updated_at)
  VALUES
  (:fn, :ln, :em, :un, :pw, :co, :ph, NOW(), NOW())
");

$stmt->execute([
  ":fn" => $first_name,
  ":ln" => $last_name,
  ":em" => $email,
  ":un" => $username,
  ":pw" => $hash,
  ":co" => ($country === "" ? null : $country),
  ":ph" => ($phone === "" ? null : $phone),
]);

$newId = $pdo->lastInsertId();

echo json_encode([
  "success" => true,
  "message" => "Sikeres regisztráció",
  "id" => $newId
]);