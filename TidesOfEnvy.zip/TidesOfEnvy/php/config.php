<?php
$host = "mysql.rackhost.hu";
$db   = "c93778tidesofenvy";
$user = "c93778CsipCsip";
$pass = "DonerKebab69";

try {
  $pdo = new PDO(
    "mysql:host=$host;dbname=$db;charset=utf8mb4",
    $user,
    $pass,
    [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]
  );
} catch (PDOException $e) {
  http_response_code(500);
  header("Content-Type: application/json; charset=utf-8");
  echo json_encode([
    "success" => false,
    "error" => "DB connection failed",
    "details" => $e->getMessage()
  ]);
  exit;
}