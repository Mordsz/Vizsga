<?php
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Csak POST kérések engedélyezettek']);
    exit;
}

// JSON adat fogadása
$data = json_decode(file_get_contents('php://input'), true);

// Validáció
$errors = [];

// Kötelező mezők
$required = ['first', 'last', 'email', 'username', 'password', 'confirm'];
foreach ($required as $field) {
    if (empty($data[$field] ?? '')) {
        $errors[$field] = 'Kötelező mező';
    }
}

// E-mail validáció
if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Érvénytelen e-mail cím';
}

// Felhasználónév validáció (3-30 karakter, csak betű, szám, alulvonás)
if (!empty($data['username'])) {
    if (strlen($data['username']) < 3 || strlen($data['username']) > 30) {
        $errors['username'] = 'A felhasználónév 3-30 karakter között legyen';
    }
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $data['username'])) {
        $errors['username'] = 'Csak betűk, számok és alulvonás engedélyezett';
    }
}

// Jelszó validáció
if (!empty($data['password'])) {
    if (strlen($data['password']) < 8) {
        $errors['password'] = 'Legalább 8 karakter szükséges';
    }
}

// Jelszó megerősítés
if ($data['password'] !== ($data['confirm'] ?? '')) {
    $errors['confirm'] = 'A jelszavak nem egyeznek';
}

// Ha vannak hibák, válasz
if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['errors' => $errors]);
    exit;
}

try {
    // Ellenőrzés: e-mail már regisztrálva?
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$data['email']]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Ez az e-mail cím már regisztrálva van']);
        exit;
    }

    // Ellenőrzés: felhasználónév már létezik?
    $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?');
    $stmt->execute([$data['username']]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Ez a felhasználónév már foglalt']);
        exit;
    }

    // Jelszó hash-elés
    $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);

    // Regisztráció
    $stmt = $pdo->prepare(
        'INSERT INTO users (first_name, last_name, email, username, password, country, phone, created_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?, NOW())'
    );

    $stmt->execute([
        $data['first'],
        $data['last'],
        $data['email'],
        $data['username'],
        $hashedPassword,
        $data['country'] ?? 'HU',
        $data['phone'] ?? null
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Sikeres regisztráció! Szívesen üdvözlünk!'
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Szerverhiba: ' . $e->getMessage()]);
}
?>
