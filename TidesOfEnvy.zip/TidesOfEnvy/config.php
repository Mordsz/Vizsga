<?php
// MySQL Adatbázis Konfigurációs Fájl
// MÓDOSÍTSD AZ ALÁBBI ADATOKAT A SAJÁT MYSQL CREDENTIALS-EDDEL!

define('DB_HOST', 'localhost');        // MySQL host (általában 'localhost')
define('DB_USER', 'root');             // MySQL felhasználónév
define('DB_PASS', '');                 // MySQL jelszó
define('DB_NAME', 'tidesofenvy');      // Adatbázis neve

// PDO Kapcsolat
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Adatbázis kapcsolati hiba']);
    exit;
}

// CORS Headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');
?>
