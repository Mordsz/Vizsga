<?php
declare(strict_types=1);

// Update these constants to match your hosting provider's database credentials.
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_NAME = 'tidesofenvy';
const DB_PASS = '';
