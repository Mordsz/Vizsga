using Godot;
using System;

public enum Direction
{
    Up,
    Down,
    Left,
    Right
}

public partial class Player : CharacterBody2D
{
    public const float Speed = 80.0f;

    private Direction _lastDirection = Direction.Down; // Utolsó mozgásirány
    private AnimatedSprite2D _animatedSprite; // Gyors elérés az AnimatedSprite2D-hez

    public override void _Ready()
    {
        _animatedSprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
    }

    public override void _PhysicsProcess(double delta)
    {
        HandleMovement(delta);
        HandleAnimation();
    }

    private void HandleMovement(double delta)
    {
        Vector2 direction = Input.GetVector("move_left", "move_right", "move_up", "move_down");
        Velocity = direction * Speed;
        MoveAndSlide();
    }

    private void HandleAnimation()
    {
        Vector2 direction = Input.GetVector("move_left", "move_right", "move_up", "move_down");

        if (direction == Vector2.Zero)
        {
            PlayIdleAnimation();
            return;
        }

        if (direction.Y != 0) // Függőleges mozgás (fel/le)
        {
            if (direction.Y < 0)
                SetAnimation(Direction.Up, "Up");
            else if (direction.Y > 0)
                SetAnimation(Direction.Down, "Down");
        }
        else if (direction.X != 0) // Vízszintes mozgás (balra/jobbra)
        {
            if (direction.X < 0)
                SetAnimation(Direction.Left, "Right", flipH: true);
            else if (direction.X > 0)
                SetAnimation(Direction.Right, "Right", flipH: false);
        }

        _animatedSprite.Play();
    }

    private void PlayIdleAnimation()
    {
        switch (_lastDirection)
        {
            case Direction.Up:
                _animatedSprite.Animation = "Up_idle";
                break;
            case Direction.Down:
                _animatedSprite.Animation = "Down_idle";
                break;
            case Direction.Left:
                _animatedSprite.Animation = "Right_idle";
                _animatedSprite.FlipH = true;
                break;
            case Direction.Right:
                _animatedSprite.Animation = "Right_idle";
                _animatedSprite.FlipH = false;
                break;
        }

        _animatedSprite.Play();
    }

    private void SetAnimation(Direction direction, string animation, bool flipH = false)
    {
        _animatedSprite.Animation = animation;
        _animatedSprite.FlipH = flipH;
        _lastDirection = direction;
    }
}
