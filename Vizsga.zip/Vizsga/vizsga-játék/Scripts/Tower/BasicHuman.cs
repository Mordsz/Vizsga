using Godot;
using System.Collections.Generic;

public partial class BasicHuman : StaticBody2D
{
    private const string TowerAreaPath = "Tower";
    private const string ArrowContainerPath = "ArrowContainer";
    private const string AimPath = "Aim";

    [Export(PropertyHint.File, "*.tscn")]
    public string BulletScenePath = "res://Scenes/Towers/Arrow.tscn";

    [Export] public int BulletDamage { get; set; } = 10;
    [Export] public float FireRate { get; set; } = 0.5f;

    private PackedScene _bulletScene;
    private Area2D _towerArea;
    private Node _arrowContainer;
    private Node2D _aimPoint;
    private Timer _fireTimer;

    public override void _Ready()
    {
        _bulletScene = GD.Load<PackedScene>(BulletScenePath);

        _towerArea = GetNode<Area2D>(TowerAreaPath);
        _arrowContainer = GetNode<Node>(ArrowContainerPath);
        _aimPoint = GetNode<Node2D>(AimPath);

        _fireTimer = new Timer
        {
            WaitTime = FireRate,
            Autostart = true,
            OneShot = false
        };
        AddChild(_fireTimer);

        _fireTimer.Timeout += TryShoot;
    }

    private void TryShoot()
    {
        var goblins = CollectGoblinFollowers();
        if (goblins.Count == 0)
            return;

        var target = SelectFurthestGoblin(goblins);
        SpawnBullet(target);
    }

    private List<PathFollow2D> CollectGoblinFollowers()
    {
        var list = new List<PathFollow2D>();

        foreach (var body in _towerArea.GetOverlappingBodies())
        {
            if (body is Goblin goblin)
            {
                if (goblin.GetParent() is PathFollow2D pf)
                    list.Add(pf);
            }
        }

        return list;
    }

    private PathFollow2D SelectFurthestGoblin(List<PathFollow2D> list)
    {
        PathFollow2D best = null;

        foreach (var pf in list)
        {
            if (best == null || pf.Progress > best.Progress)
                best = pf;
        }

        return best;
    }

    private void SpawnBullet(PathFollow2D target)
    {
        if (target == null)
            return;

        var bullet = _bulletScene.Instantiate<Arrow>();
        bullet.Target = target;
        bullet.BulletDamage = BulletDamage;

        _arrowContainer.AddChild(bullet);
        bullet.GlobalPosition = _aimPoint.GlobalPosition;
    }
}
