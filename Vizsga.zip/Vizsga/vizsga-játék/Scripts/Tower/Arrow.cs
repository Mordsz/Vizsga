using Godot;

public partial class Arrow : CharacterBody2D
{
    [Export] public float Speed { get; set; } = 1000f;
    [Export] public int BulletDamage { get; set; }
    public Node2D Target { get; set; }

    public override void _PhysicsProcess(double delta)
    {
        if (Target == null || !IsInstanceValid(Target))
        {
            QueueFree();
            return;
        }

        Vector2 targetPos = Target.GlobalPosition;
        Velocity = GlobalPosition.DirectionTo(targetPos) * Speed;
        LookAt(targetPos);
        MoveAndSlide();
    }

    private void _on_Area2D_body_entered(Node body)
    {
        if (body is Goblin goblin)
        {
            goblin.ApplyDamage(BulletDamage);
            QueueFree();
        }
    }
}
