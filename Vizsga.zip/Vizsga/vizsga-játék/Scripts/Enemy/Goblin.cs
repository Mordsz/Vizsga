using Godot;

public partial class Goblin : CharacterBody2D
{
    [Export] public float Speed { get; set; } = 80f;
    [Export] public int Health { get; private set; } = 10;

    private PathFollow2D _pathFollow;
    private bool _isDead;

    public override void _Ready()
    {
        _pathFollow = GetParentOrNull<PathFollow2D>();
    }

    public override void _Process(double delta)
    {
        if (_pathFollow == null || _isDead)
            return;

        _pathFollow.Progress += Speed * (float)delta;

        if (_pathFollow.ProgressRatio >= 1f)
            QueueFree();
    }

    public void ApplyDamage(int amount)
    {
        if (_isDead)
            return;

        Health -= amount;
        if (Health <= 0)
            Die();
    }

    private void Die()
    {
        _isDead = true;
        QueueFree(); // csak a goblin tűnik el
    }
}
