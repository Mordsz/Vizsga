using Godot;
using System;

public partial class Npc : CharacterBody2D
{
    public override void _Ready()
    {
        AnimatedSprite2D animatedSprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
        animatedSprite.Play("default");
    }
}
