using Godot;
using System;

public partial class Enter : Area2D
{
	private bool isInside = false;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		BodyEntered += PlayerEntersHouse;
        BodyExited += PlayerExitsHouse;
	}

	private void PlayerEntersHouse(Node2D body)
	{	
		isInside = true;
		if (body is Player player)
        {
            GD.Print($"A játékos belépett az Area2D-be: {player.Name}");
        }
	}


	
	private void PlayerExitsHouse(Node2D body)
	{
		isInside = false;
		if (body is Player player)
        {
            GD.Print($"A játékos kilépett az Area2D-ből: {player.Name}");
        }
	}

	public override void _Process(double delta)
    {
        // Csak akkor fut, amikor a játékos bent van
        if (isInside && Input.IsActionJustPressed("interaction"))
        {
            GD.Print("Beléptél a házba!");
        }
    }
}
