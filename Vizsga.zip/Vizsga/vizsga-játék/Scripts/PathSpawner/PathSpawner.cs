using Godot;

public partial class PathSpawner : Node2D
{
	[Export] private Timer SpawnTimer; // Timer driving when new paths are spawned
	private readonly PackedScene _pathScene = GD.Load<PackedScene>("res://Scenes/Stages/Stage 1.tscn");

	public override void _Ready()
	{
		if (SpawnTimer == null)
		{
			GD.PushError("PathSpawner needs a Timer assigned in the inspector.");
			return;
		}

		SpawnTimer.Timeout += OnSpawnTimerTimeout;
		if (SpawnTimer.IsStopped())
		{
			SpawnTimer.Start();
		}
	}

	public override void _ExitTree()
	{
		if (SpawnTimer != null)
		{
			SpawnTimer.Timeout -= OnSpawnTimerTimeout;
		}
	}

	private void OnSpawnTimerTimeout()
	{
		if (_pathScene == null)
		{
			return;
		}

		var tempPath = _pathScene.Instantiate<Node2D>();
		AddChild(tempPath);
	}
}
