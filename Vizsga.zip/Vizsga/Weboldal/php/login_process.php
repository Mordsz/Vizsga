<?php
declare(strict_types=1);

session_start();

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.html');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    header('Location: ../login.html?error=missing');
    exit;
}

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    $stmt = $db->prepare('SELECT id, password FROM users WHERE username = ? LIMIT 1');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        $stmt->close();
        $db->close();
        header('Location: ../login.html?error=1');
        exit;
    }

    $stmt->bind_result($userId, $hashedPassword);
    $stmt->fetch();
    $stmt->close();
    $db->close();

    if (password_verify($password, $hashedPassword)) {
        $_SESSION['user'] = $username;
        $_SESSION['user_id'] = $userId;
        header('Location: ../main.php');
        exit;
    }

    header('Location: ../login.html?error=1');
    exit;
} catch (mysqli_sql_exception $exception) {
    error_log('Login error: ' . $exception->getMessage());
    header('Location: ../login.html?error=server');
    exit;
}
