using Godot;
using System;

public partial class Map : Node2D
{
    public override void _Ready()
    {
        InitialiseMana();
    }   
    public void InitialiseMana()
    {
        Mana.mana = 100;
    }
}
