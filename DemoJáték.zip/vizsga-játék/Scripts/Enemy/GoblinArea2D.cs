using Godot;
using System;

public partial class GoblinArea2D : Area2D
{
	public Goblin GetEnemy2D()
	{
		return GetParent<Goblin>();
	}
}
