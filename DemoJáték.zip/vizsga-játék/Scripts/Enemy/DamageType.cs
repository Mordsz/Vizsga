using Godot;
using System;

public enum DamageType
{
    Physical,
    Fire,
    Ice,
    Electric
}

