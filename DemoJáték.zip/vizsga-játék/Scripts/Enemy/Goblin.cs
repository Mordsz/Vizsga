using Godot;
using System;
public partial class Goblin : PathFollow2D
{
    [ExportCategory("Node Connections")]
    [Export] public Label nameLabel;
    [Export] public Label healthLabel;
    [ExportCategory("Stats")]
    [Export] public int maxHealth = 10;

    [Export] public float speed = 100.0f;
    public int currentHealth;
    


    public override void _Ready()
    {
        RenameEnemy("Goblin");
        InitialiseHealth(maxHealth);
        CheckHealthAndUpdateLabel();
    }

    private static String packedScenePath = "uid://dvrfnsa8xhfrj";

    public static Goblin CreateEnemy()
    {
       return ResourceLoader.Load<PackedScene>(packedScenePath).Instantiate<Goblin>();
    }

    public override void _PhysicsProcess(double delta)
    {
      Move(delta);
    }

    public void Move(double delta)
    {
       Progress += (float) delta * speed;
        if (ProgressRatio >= 1.0f)
        {
            Banish();
        }

    }

    public void RenameEnemy(string a_text)
    {
        nameLabel.Text = a_text;
    }

    public void UpdateHealthLabel()
    {
        healthLabel.Text = $"{currentHealth}/{maxHealth}";
    }

    public void InitialiseHealth(int a_health)
    {
        maxHealth = a_health;
        currentHealth = a_health;
        UpdateHealthLabel();
    }

    public void CheckHealthAndUpdateLabel()
    {
        if (currentHealth <= 0)
        {
            Mana.Create(20);
            WaveController.Instance.OnEnemyDied();
            QueueFree();
        }
        else
        {
            UpdateHealthLabel();
        }
    }

    public void TakeDamage(int a_damage)
    {
        currentHealth -= a_damage;
        CheckHealthAndUpdateLabel();
    }

    public void Banish()
    {
        GD.Print("Enemy has reached the end.");
        Mana.Consume(15);
        WaveController.Instance.OnEnemyDied();
        QueueFree();
    }
}
