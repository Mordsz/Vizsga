using Godot;
using System;

public partial class MinotaurArea2D : Area2D
{
	public Minotaur GetEnemy2D()
	{
		return GetParent<Minotaur>();
	}
}
