using Godot;
using System;

public partial class Mana
{
    public static int mana;

    public static void Create(int a_quantity)
    {
        if (a_quantity < 0)
        {
            GD.PrintErr("Cannot create negative Mana.");
            return;
        }

        mana += a_quantity;
    }

    public static bool Consume(int a_quantity)
    {
        if (a_quantity < 0)
        {
            GD.PrintErr("Cannot consume negative Mana.");
            return false;
        }

        if(a_quantity > mana)
        {
            GD.PrintErr("Not enough Mana to consume.");
            return false;
        }

        if(!CanAfford(a_quantity))
        {
            return false;
        }

        mana -= a_quantity;
        return true;
    }

    public static bool CanAfford(int a_quantity)
    {
        return a_quantity <= mana;
    }
}
