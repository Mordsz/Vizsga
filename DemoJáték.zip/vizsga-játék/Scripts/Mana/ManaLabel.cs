using Godot;
using System;

public partial class ManaLabel : Label
{

    public override void _Process(double delta)
    {
        
        Text = $"Mana: {Mana.mana}";
    }

}
