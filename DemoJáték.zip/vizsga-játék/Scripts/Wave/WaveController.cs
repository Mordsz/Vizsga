using Godot;
using System.Collections.Generic;
using System.Threading.Tasks;

public partial class WaveController : Node
{
    public static WaveController Instance;

    [Export] public WaveSpawner Spawner;
    [Export] public Button NextWaveButton;

    private List<WaveData> waves = new();
    private int currentWave = 0;

    public override void _Ready()
    {
        Instance = this;

        // UI gomb elrejtése
        NextWaveButton.Visible = true;
        NextWaveButton.Pressed += OnNextWavePressed;

        // Itt hozzuk létre a wave-eket
        LoadWaves();
    }

    public int aliveEnemies = 0;

    public void OnEnemyDied()
    {
        aliveEnemies--;

        if (aliveEnemies <= 0)
        {
            NextWaveButton.Visible = true;
        }
    }

    private void LoadWaves()
    {
        var enemyScene = GD.Load<PackedScene>("res://Scenes/Characters/Enemy2d.tscn");

        waves.Add(new WaveData(enemyScene, 5, 0.8f));   // Wave 1
        waves.Add(new WaveData(enemyScene, 10, 0.8f));  // Wave 2
        waves.Add(new WaveData(enemyScene, 15, 0.8f));  // Wave 3
        waves.Add(new WaveData(enemyScene, 20, 0.8f));  // Wave 4
        waves.Add(new WaveData(enemyScene, 20, 0.6f));  // Wave 5
        waves.Add(new WaveData(enemyScene, 20, 0.6f));  // Wave 6
        waves.Add(new WaveData(enemyScene, 20, 0.6f));  // Wave 7
        waves.Add(new WaveData(enemyScene, 20, 0.4f));  // Wave 8
        waves.Add(new WaveData(enemyScene, 20, 0.4f));  // Wave 9
        waves.Add(new WaveData(enemyScene, 20, 0.4f));  // Wave 10
    }

    private void OnNextWavePressed()
    {
        NextWaveButton.Visible = false;
        StartWave();
    }

    private async void StartWave()
    {
        
        if (currentWave >= waves.Count)
        {
            GD.Print("All waves completed!");
            return;
        }

        var wave = waves[currentWave];
        await RunWave(wave);

        currentWave++;     
    }

    private async Task RunWave(WaveData wave)
    {
        aliveEnemies += wave.Count;
        for (int i = 0; i < wave.Count; i++)
        {
            Spawner.Spawn(wave.EnemyScene);
            await ToSignal(GetTree().CreateTimer(wave.Interval), "timeout");
        }
    }
}
