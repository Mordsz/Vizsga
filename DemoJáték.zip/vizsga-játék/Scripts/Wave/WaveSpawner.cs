using Godot;

public partial class WaveSpawner : Node2D
{
    [Export] public Path2D Path;

    public void Spawn(PackedScene enemyScene)
    {
        var enemy = enemyScene.Instantiate<Node2D>();
        Path.AddChild(enemy);
    }
}
