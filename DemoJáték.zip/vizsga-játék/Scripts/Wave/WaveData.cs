using Godot;

public class WaveData
{
    public PackedScene EnemyScene;
    public int Count;
    public float Interval;

    public WaveData(PackedScene scene, int count, float interval)
    {
        EnemyScene = scene;
        Count = count;
        Interval = interval;
    }
}
