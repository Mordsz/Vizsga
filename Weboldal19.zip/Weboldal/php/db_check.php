<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

header('Content-Type: text/plain; charset=utf-8');

try {
    $db = db();
    echo "DB connection OK\n";
    echo "Host: " . DB_HOST . "\n";
    echo "User: " . DB_USER . "\n";
    echo "Database: " . DB_NAME . "\n\n";

    $tables = [
        'users' => [
            'id', 'username', 'password', 'email', 'is_admin', 'account_status', 'chat_enabled', 'created_at'
        ],
        'friends' => [
            'id', 'user_id', 'friend_id', 'created_at'
        ],
        'friend_requests' => [
            'id', 'sender_id', 'receiver_id', 'status', 'created_at'
        ],
        'messages' => [
            'id', 'sender_id', 'receiver_id', 'message', 'created_at'
        ],
    ];

    foreach ($tables as $table => $columns) {
        echo "Checking table: {$table}\n";
        $stmt = $db->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? LIMIT 1');
        $stmt->bind_param('ss', DB_NAME, $table);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 0) {
            echo "  MISSING table: {$table}\n\n";
            $stmt->close();
            continue;
        }
        $stmt->close();

        foreach ($columns as $column) {
            $colStmt = $db->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1');
            $colStmt->bind_param('sss', DB_NAME, $table, $column);
            $colStmt->execute();
            $colStmt->store_result();
            if ($colStmt->num_rows === 0) {
                echo "  MISSING column in {$table}: {$column}\n";
            }
            $colStmt->close();
        }
        echo "\n";
    }
} catch (Throwable $exception) {
    echo 'ERROR: ' . $exception->getMessage() . "\n";
    if (function_exists('mysqli_connect_error')) {
        echo 'MySQLi error: ' . mysqli_connect_error() . "\n";
    }
    error_log('db_check error: ' . $exception->getMessage());
}
