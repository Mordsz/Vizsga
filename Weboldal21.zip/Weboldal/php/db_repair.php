<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

header('Content-Type: text/plain; charset=utf-8');

function tableExists(mysqli $db, string $table): bool
{
    $schema = DB_NAME;
    $stmt = $db->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? LIMIT 1');
    $stmt->bind_param('ss', $schema, $table);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();
    return $exists;
}

function columnExists(mysqli $db, string $table, string $column): bool
{
    $schema = DB_NAME;
    $stmt = $db->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1');
    $stmt->bind_param('sss', $schema, $table, $column);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();
    return $exists;
}

try {
    $db = db();
    echo "DB connection OK\n";
    echo "Host: " . DB_HOST . "\n";
    echo "Database: " . DB_NAME . "\n\n";

    if (!tableExists($db, 'users')) {
        echo "ERROR: users table does not exist.\n";
        exit(1);
    }

    $columnDefinitions = [
        'chat_enabled' => 'TINYINT(1) NOT NULL DEFAULT 1',
        'is_admin' => 'TINYINT(1) NOT NULL DEFAULT 0',
        'account_status' => "ENUM('active','disabled') NOT NULL DEFAULT 'active'",
        'last_active' => 'DATETIME NULL DEFAULT NULL',
        'last_login' => 'DATETIME NULL DEFAULT NULL',
        'avatar' => 'VARCHAR(255) DEFAULT NULL',
        'bio' => 'TEXT DEFAULT NULL',
    ];

    foreach ($columnDefinitions as $column => $definition) {
        if (!columnExists($db, 'users', $column)) {
            $db->query("ALTER TABLE users ADD COLUMN {$column} {$definition}");
            echo "Added users.{$column}\n";
        } else {
            echo "users.{$column} already exists\n";
        }
    }

    if (!tableExists($db, 'friends')) {
        $db->query("CREATE TABLE friends (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            friend_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY unique_friendship (user_id, friend_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "Created friends table\n";
    } else {
        echo "friends table already exists\n";
    }

    if (!tableExists($db, 'friend_requests')) {
        $db->query("CREATE TABLE friend_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            status ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY unique_request (sender_id, receiver_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "Created friend_requests table\n";
    } else {
        echo "friend_requests table already exists\n";
    }

    if (!tableExists($db, 'messages')) {
        $db->query("CREATE TABLE messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NULL DEFAULT NULL,
            FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_conversation (sender_id, receiver_id),
            INDEX idx_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "Created messages table\n";
    } else {
        echo "messages table already exists\n";
    }

    echo "\nRepair completed.\n";
} catch (Throwable $exception) {
    echo 'ERROR: ' . $exception->getMessage() . "\n";
    error_log('db_repair error: ' . $exception->getMessage());
}
