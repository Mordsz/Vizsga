using System.Windows;
using System.Windows.Media;

namespace Launcher
{
    public partial class CustomMessageBox : Window
    {
        public enum MessageType
        {
            Info,
            Success,
            Warning,
            Error
        }

        private CustomMessageBox(string message, string title, MessageType type)
        {
            InitializeComponent();
            
            txtMessage.Text = message;
            txtTitle.Text = title;
            
            SetIcon(type);
        }

        private void SetIcon(MessageType type)
        {
            switch (type)
            {
                case MessageType.Info:
                    iconPath.Fill = new SolidColorBrush(Color.FromRgb(138, 168, 198)); // K�k-sz�rke
                    iconPath.Data = Geometry.Parse("M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M11,16.5L6.5,12L7.91,10.59L11,13.67L16.59,8.09L18,9.5L11,16.5Z");
                    break;

                case MessageType.Success:
                    iconPath.Fill = new SolidColorBrush(Color.FromRgb(106, 150, 90)); // Z�ld
                    iconPath.Data = Geometry.Parse("M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22A10,10 0 0,1 2,12A10,10 0 0,1 12,2M12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4M11,16.5L6.5,12L7.91,10.59L11,13.67L16.59,8.09L18,9.5L11,16.5Z");
                    break;

                case MessageType.Warning:
                    iconPath.Fill = new SolidColorBrush(Color.FromRgb(218, 160, 90)); // Narancss�rga/arany
                    iconPath.Data = Geometry.Parse("M12,2L1,21H23M12,6L19.53,19H4.47M11,10V14H13V10M11,16V18H13V16");
                    break;

                case MessageType.Error:
                    iconPath.Fill = new SolidColorBrush(Color.FromRgb(190, 80, 60)); // Piros/barna
                    iconPath.Data = Geometry.Parse("M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z");
                    break;
            }
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        public static void Show(string message, string title = "Uzenet", MessageType type = MessageType.Info)
        {
            var messageBox = new CustomMessageBox(message, title, type);
            messageBox.ShowDialog();
        }

        public static void ShowInfo(string message, string title = "Informacio")
        {
            Show(message, title, MessageType.Info);
        }

        public static void ShowSuccess(string message, string title = "Sikeres")
        {
            Show(message, title, MessageType.Success);
        }

        public static void ShowWarning(string message, string title = "Figyelmezetes")
        {
            Show(message, title, MessageType.Warning);
        }

        public static void ShowError(string message, string title = "Hiba")
        {
            Show(message, title, MessageType.Error);
        }
    }
}
