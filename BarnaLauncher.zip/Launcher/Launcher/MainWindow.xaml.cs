﻿using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Launcher
{
 public partial class MainWindow : Window
 {
 private const string ConfigFile = "launcher.config";
 private const string LoginApiUrl = "https://tidesofenvy.hu/php/login_process.php"; // UPDATE THIS URL!
 
 private bool isLoggedIn = false;
 private string currentUser = string.Empty;
 private static readonly HttpClient httpClient = new HttpClient();

 public MainWindow()
 {
 InitializeComponent();
 LoadSettings();
 UpdateLoginUI();
 }

 private void UpdateLoginUI()
 {
 if (isLoggedIn)
 {
 pnlLogin.Visibility = Visibility.Collapsed;
 pnlUserInfo.Visibility = Visibility.Visible;
 txtLoggedUser.Text = currentUser;
 }
 else
 {
 pnlLogin.Visibility = Visibility.Visible;
 pnlUserInfo.Visibility = Visibility.Collapsed;
 }
 }

 private async void btnLogin_Click(object sender, RoutedEventArgs e)
 {
 var username = txtUsername.Text.Trim();
 var password = txtPassword.Password;

 if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
 {
 CustomMessageBox.ShowWarning("Kérlek add meg a felhasználónevet és a jelszót!", "Hiányzó adatok");
 return;
 }

 btnLogin.IsEnabled = false;
 txtStatus.Text = "Bejelentkezés...";

 bool success = await AuthenticateUserAsync(username, password);

 if (success)
 {
 isLoggedIn = true;
 currentUser = username;
 UpdateLoginUI();
 txtStatus.Text = "Sikeres belépés!";
 CustomMessageBox.ShowSuccess($"Üdvözöljük, {username}!", "Belépés sikeres");
 }
 else
 {
 CustomMessageBox.ShowError("Hibás felhasználónév vagy jelszó!", "Bejelentkezési hiba");
 txtStatus.Text = "Sikertelen belépés.";
 }

 btnLogin.IsEnabled = true;
 }

 private async Task<bool> AuthenticateUserAsync(string username, string password)
 {
 try
 {
 var formData = new FormUrlEncodedContent(new[]
 {
 new KeyValuePair<string, string>("username", username),
 new KeyValuePair<string, string>("password", password)
 });

 HttpResponseMessage response = await httpClient.PostAsync(LoginApiUrl, formData);
 
 // Olvassuk ki a válasz tartalmát
 string responseText = await response.Content.ReadAsStringAsync();
 
 // Debug információ
 System.Diagnostics.Debug.WriteLine($"HTTP Status: {response.StatusCode}");
 System.Diagnostics.Debug.WriteLine($"Response: {responseText}");
 
 // A PHP JSON-t ad vissza, pl: {"success":true,"username":"Aronka","user_id":9}
 // vagy {"success":false,"error":"invalid_credentials"}
 
 if (string.IsNullOrWhiteSpace(responseText))
 {
 CustomMessageBox.ShowError("Üres válasz a szervertől!", "Szerver hiba");
 return false;
 }
 
 // Ellenőrizzük, hogy HTML-t kaptunk-e vissza JSON helyett
 if (responseText.TrimStart().StartsWith("<") || responseText.Contains("<html") || responseText.Contains("<!DOCTYPE"))
 {
 CustomMessageBox.ShowError("A szerver HTML oldalt küldött JSON helyett!\n\nLehet, hogy rossz az URL, vagy a PHP fájl nem érhető el.\n\nEllenőrizd az URL-t: " + LoginApiUrl, "Szerver konfiguráció hiba");
 return false;
 }
 
 // JSON válasz ellenőrzése
 if (responseText.Contains("\"success\":true") || responseText.Contains("\"success\": true"))
 {
 return true;
 }
 
 if (responseText.Contains("\"success\":false") || responseText.Contains("\"success\": false"))
 {
 if (responseText.Contains("invalid_credentials"))
 {
 return false;
 }
 else if (responseText.Contains("missing_fields"))
 {
 CustomMessageBox.ShowWarning("Hiányzó mezők!", "Hiba");
 return false;
 }
 else if (responseText.Contains("server_error"))
 {
 CustomMessageBox.ShowError("Szerver hiba történt. Próbáld újra később!", "Szerver hiba");
 return false;
 }
 else if (responseText.Contains("invalid_method"))
 {
 CustomMessageBox.ShowError("Érvénytelen kérés! A szerver csak POST kérést fogad.", "Hiba");
 return false;
 }
 
 return false;
 }
 
 // Ha egyáltalán nem JSON formátum
 CustomMessageBox.ShowError($"Nem JSON választ kaptunk a szervertől!\n\nVálasz előnézet:\n{responseText.Substring(0, Math.Min(200, responseText.Length))}...", "Formátum hiba");
 return false;
 }
 catch (HttpRequestException ex)
 {
 CustomMessageBox.ShowError($"Hálózati hiba: {ex.Message}\n\nEllenőrizd az internet kapcsolatot és hogy a szerver URL helyes:\n{LoginApiUrl}", "Kapcsolódási hiba");
 return false;
 }
 catch (Exception ex)
 {
 CustomMessageBox.ShowError($"Váratlan hiba: {ex.Message}", "Hiba");
 return false;
 }
 }

 private void btnLogout_Click(object sender, RoutedEventArgs e)
 {
 isLoggedIn = false;
 currentUser = string.Empty;
 txtUsername.Text = string.Empty;
 txtPassword.Password = string.Empty;
 UpdateLoginUI();
 txtStatus.Text = "Kijelentkezve.";
 }

 private void btnBrowse_Click(object sender, RoutedEventArgs e)
 {
 var dlg = new OpenFileDialog();
 dlg.Filter = "Executable|*.exe|All files|*.*";
 dlg.Title = "Válaszd ki a játék végrehajtható fájlját";
 if (dlg.ShowDialog() == true)
 {
 txtExePath.Text = dlg.FileName;
 txtStatus.Text = "Játék útvonal beállítva.";
 SaveSettings();
 }
 }

 private void btnClear_Click(object sender, RoutedEventArgs e)
 {
 txtExePath.Text = string.Empty;
 txtStatus.Text = "Útvonal törölve.";
 SaveSettings();
 }

 private void btnStart_Click(object sender, RoutedEventArgs e)
 {
 if (!isLoggedIn)
 {
 CustomMessageBox.ShowWarning("Először be kell jelentkezned a játék indításához!", "Bejelentkezés szükséges");
 return;
 }

 var path = txtExePath.Text;
 if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
 {
 CustomMessageBox.ShowError("Kérlek válaszd ki a játék végrehajtható fájlját először!", "Hiányzó játék útvonal");
 return;
 }

 try
 {
 var startInfo = new ProcessStartInfo(path)
 {
 WorkingDirectory = Path.GetDirectoryName(path)
 };
 Process.Start(startInfo);
 txtStatus.Text = "Játék elindítva!";
 SaveSettings();
 }
 catch (Exception ex)
 {
 CustomMessageBox.ShowError("Nem sikerült elindítani a játékot: " + ex.Message, "Indítási hiba");
 txtStatus.Text = "Indítás sikertelen.";
 }
 }

 private void LoadSettings()
 {
 try
 {
 if (!File.Exists(ConfigFile))
 return;
 var lines = File.ReadAllLines(ConfigFile);
 foreach (var line in lines)
 {
 if (line.StartsWith("exe="))
 txtExePath.Text = line.Substring(4).Trim();
 }
 txtStatus.Text = "Beállítások betöltve.";
 }
 catch
 {
 // ignore
 }
 }

 private void SaveSettings()
 {
 try
 {
 var lines = new System.Collections.Generic.List<string>();
 lines.Add("exe=" + (txtExePath?.Text ?? string.Empty));
 File.WriteAllLines(ConfigFile, lines);
 }
 catch
 {
 // ignore
 }
 }
 }
}
