<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$auth = require_auth();
if (!$auth['is_admin']) {
    json_error('not_authorized', 'Csak admin jogosultsággal érhető el', 403);
}

$db = db();

$stmt = $db->prepare('SELECT username, created_at FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY) ORDER BY created_at DESC LIMIT 10');
$stmt->execute();
$result = $stmt->get_result();

$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = [
        'username' => $row['username'],
        'created_at' => $row['created_at']
    ];
}
$stmt->close();

json_success(['users' => $users]);
