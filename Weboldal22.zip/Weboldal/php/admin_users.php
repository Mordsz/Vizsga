﻿<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$auth = require_auth();
if (!$auth['is_admin']) {
    json_error('not_authorized', 'Csak admin jogosultsággal érhető el', 403);
}

$db = db();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $fields = [
        'id',
        'username',
        'email',
        usersColumnExists($db, 'account_status') ? 'account_status' : "'active' AS account_status",
        usersColumnExists($db, 'last_active') ? 'last_active' : 'NULL AS last_active',
        usersColumnExists($db, 'is_admin') ? 'is_admin' : '0 AS is_admin',
        usersColumnExists($db, 'online_since') ? 'online_since' : 'NULL AS online_since',
        'avatar',
        usersColumnExists($db, 'chat_enabled') ? 'chat_enabled' : '0 AS chat_enabled',
        'created_at'
    ];

    $query = 'SELECT ' . implode(', ', $fields) . ' FROM users ORDER BY username ASC';
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $online = false;
        if (!empty($row['online_since'])) {
            $online = strtotime($row['online_since']) >= strtotime('-5 minutes');
        }

        $users[] = [
            'id' => (int)$row['id'],
            'username' => $row['username'],
            'email' => $row['email'],
            'status' => $row['account_status'],
            'last_active' => $row['last_active'],
            'is_admin' => (int)$row['is_admin'] === 1,
            'online' => $online,
            'chat_enabled' => (int)$row['chat_enabled'] === 1,
            'created_at' => $row['created_at']
        ];
    }

    json_success(['users' => $users]);
}

require_method('POST');
$action = trim($_POST['action'] ?? '');
$userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

if ($userId <= 0) {
    json_error('invalid_user', 'Érvénytelen felhasználó azonosító');
}

if ($action === 'toggle_status') {
    $status = trim($_POST['status'] ?? '');
    if ($status !== 'active' && $status !== 'disabled') {
        json_error('invalid_status', 'Ismeretlen státusz');
    }

    $stmt = $db->prepare('SELECT is_admin FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->bind_result($targetIsAdmin);
    if (!$stmt->fetch()) {
        $stmt->close();
        json_error('user_not_found', 'A felhasználó nem található');
    }
    $stmt->close();

    if ((int)$targetIsAdmin === 1) {
        json_error('cannot_modify_admin', 'Admin fiók nem módosítható');
    }

    $stmt = $db->prepare('UPDATE users SET account_status = ? WHERE id = ?');
    $stmt->bind_param('si', $status, $userId);
    $stmt->execute();
    $stmt->close();

    json_success();
}

if ($action === 'delete_user') {
    $stmt = $db->prepare('SELECT is_admin FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->bind_result($targetIsAdmin);
    if (!$stmt->fetch()) {
        $stmt->close();
        json_error('user_not_found', 'A felhasználó nem található');
    }
    $stmt->close();

    if ((int)$targetIsAdmin === 1) {
        json_error('cannot_delete_admin', 'Admin fiók nem törölhető');
    }

    $stmt = $db->prepare('DELETE FROM users WHERE id = ? AND is_admin = 0');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $deleted = $stmt->affected_rows;
    $stmt->close();

    if ($deleted === 0) {
        json_error('delete_failed', 'A felhasználó törlése nem sikerült');
    }

    json_success();
}

if ($action === 'toggle_chat') {
    $enabled = isset($_POST['enabled']) ? (int)$_POST['enabled'] : 0;
    if ($enabled !== 0 && $enabled !== 1) {
        json_error('invalid_value', 'Hibás érték érkezett');
    }

    $stmt = $db->prepare('SELECT is_admin FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->bind_result($targetIsAdmin);
    if (!$stmt->fetch()) {
        $stmt->close();
        json_error('user_not_found', 'A felhasználó nem található');
    }
    $stmt->close();

    if ((int)$targetIsAdmin === 1) {
        json_error('cannot_modify_admin', 'Admin fiók chatjét nem módosíthatod');
    }

    $stmt = $db->prepare('UPDATE users SET chat_enabled = ? WHERE id = ?');
    $stmt->bind_param('ii', $enabled, $userId);
    $stmt->execute();
    $stmt->close();

    json_success();
}

if ($action === 'grant_admin') {
    if ($userId === $auth['user_id']) {
        json_error('cannot_grant_self', 'Magadat nem kell adminná tenned');
    }

    $stmt = $db->prepare('SELECT is_admin FROM users WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->bind_result($targetIsAdmin);
    if (!$stmt->fetch()) {
        $stmt->close();
        json_error('user_not_found', 'A felhasználó nem található');
    }
    $stmt->close();

    if ((int)$targetIsAdmin === 1) {
        json_error('already_admin', 'A felhasználó már admin');
    }

    $stmt = $db->prepare('UPDATE users SET is_admin = 1 WHERE id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->close();

    json_success();
}

json_error('unknown_action', 'Ismeretlen admin művelet');
