<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

$auth = require_auth();
if (!$auth['is_admin']) {
    json_error('not_authorized', 'Csak admin jogosultsággal érhető el', 403);
}

try {
    $db = db();
    
    // Biztosítjuk, hogy van created_at mező
    ensure_user_columns([
        ['name' => 'created_at', 'definition' => 'DATETIME DEFAULT CURRENT_TIMESTAMP']
    ]);
    
    // Utolsó 24 órában regisztrált felhasználók száma
    $stmt = $db->prepare('SELECT COUNT(*) as count FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)');
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    json_success(['count' => (int)$count]);
} catch (Throwable $exception) {
    error_log('New registrations check error: ' . $exception->getMessage());
    json_error('server_error', 'Szerverhiba történt', 500);
}
