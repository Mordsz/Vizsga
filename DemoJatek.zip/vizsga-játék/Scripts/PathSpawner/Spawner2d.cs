using Godot;
using System;
using System.IO;

public partial class Spawner2d : Node2D
{
    [Export] public Timer timer;
    [Export] public float spawnInterval = 0.75f;
    [Export] public Path2D path;

    [Export] public int spawnQuantity = 10;

    public int spawnedEnemies;

    public override void _Ready() 
    {
       timer.Timeout += OnTimerTimeout;
       InitaliseTimer();
    }

    public void InitaliseTimer()
    {
        spawnedEnemies = 0;
        timer.Stop();
        timer.WaitTime = spawnInterval;
        timer.Start();
    }

    public void StopTimer()
    {
        timer.Stop();
    }

    public void CreateEnemy()
    {
        if(spawnedEnemies >= spawnQuantity)
        {
            StopTimer();
            return;
        }

        path.AddChild(Enemy2d.CreateEnemy());
        spawnedEnemies++;

    }

    public void OnTimerTimeout()
    {
        CreateEnemy();
    }
}
