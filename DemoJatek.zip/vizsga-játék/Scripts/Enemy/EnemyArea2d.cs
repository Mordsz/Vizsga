using Godot;
using System;

public partial class EnemyArea2d : Area2D
{
	public Enemy2d GetEnemy2D()
	{
		return GetParent<Enemy2d>();
	}
}
