using Godot;
using System;

public partial class Map : Node2D
{
    [Export] public Path2D path;

    public override void _Ready()
    {
        CreateEnemy();
        InitialiseMana();
    }   

    public void CreateEnemy()
    {
        path.AddChild(Enemy2d.CreateEnemy());
    }

    public void InitialiseMana()
    {
        Mana.mana = 500;
    }
}
