using Godot;
using System;

public partial class CannonBall : Node2D
{
    private const string ProjectileScenePath = "res://Scenes/Towers/CannonBall.tscn";

    public static CannonBall CreateProjectile(int a_Damage, Enemy2d a_Target)
    {
        CannonBall node = ResourceLoader.Load<PackedScene>(ProjectileScenePath).Instantiate<CannonBall>();
        node.damage = a_Damage;
        node.target = a_Target;
        return node;
    }   
}

public partial class CannonBall
{
    public int damage;
    public Enemy2d target;
    public float movementSpeed = 400.0f;

    public override void _Ready()
    {
        target.TreeExiting += OnTargetFreed;
    }

    public override void _PhysicsProcess(double delta)
    {
        MoveTowardTarget((float)delta);
    }

    public void MoveTowardTarget(float a_Delta)
    {
        Vector2 trajectory = new Vector2(target.GlobalPosition.X - GlobalPosition.X,
                                        target.GlobalPosition.Y - GlobalPosition.Y);

        if (trajectory.Length() < 16)
        {
            ApplyDamages();
            return;
        }

        Vector2 direction = trajectory.Normalized();
        float deltaMovementSpeed = movementSpeed * a_Delta;

        Vector2 newPosition = new Vector2(
            GlobalPosition.X + direction.X * deltaMovementSpeed,
            GlobalPosition.Y + direction.Y * deltaMovementSpeed
        );

        GlobalPosition = newPosition;
    }

    public void ApplyDamages()
    {
        target.TakeDamage(damage);
        QueueFree();
    }

    public void OnTargetFreed()
    {
        QueueFree();
    }
}
