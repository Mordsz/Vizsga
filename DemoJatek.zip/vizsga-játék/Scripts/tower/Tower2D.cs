using Godot;
using Godot.Collections;
using System;

public partial class Tower2D : Node2D
{

    public enum Towers
    {
        None = 0,
        Cannon = 1,  
        Ice = 2 
    }

    [ExportCategory("Stats")]
    [Export] public int damage = 4;
    [ExportCategory("Node Connections")]
    [Export] public Area2D rangeArea;
    [Export] public Timer timer;
    [Export] public Button TowerButton;  
    [Export] public Sprite2D TowerSprite;
    [Export] public Control towerMenu;
    [Export] public Button iceTowerButton;
    [Export] public Button cannonTowerButton;
    [ExportCategory("Textures")]
    [Export] public Texture2D iceTowerTexture;

    
    public Array<Enemy2d> enemiesInRange;
    public Towers towerEnums;
    public static Texture2D cannonTowerTexture;
    
    public Tower2D()
    {
        enemiesInRange = new Array<Enemy2d>();
    }

    public override void _Ready()
    {
        cannonTowerTexture = ResourceLoader.Load<Texture2D>("uid://mv2jyvq3visb");

        towerEnums = Towers.None;
        rangeArea.AreaEntered += OnAreaEntered;
        rangeArea.AreaExited += OnAreaExited;
        TowerButton.Pressed += OnTowerButtonPressed;
        towerMenu.Visible = false;

        iceTowerButton.Pressed += InitialiseIceTower;
        cannonTowerButton.Pressed += InitialiseCannonTower;
    }

    public override void _PhysicsProcess(double delta)
    {
        if(towerEnums == Towers.None)
        {
            return;
        }

        if(HasEnemiesInRange() && !IsInCooldown())
        {
            Attack(enemiesInRange.PickRandom());
        }
    }

    public bool HasEnemiesInRange()
    {
        return enemiesInRange.Count > 0;
    }

    public bool IsInCooldown()
    {
        return (timer.TimeLeft > 0);
    }   

    public void Attack(Enemy2d enemy)
    {
        AddChild(CannonBall.CreateProjectile(damage, enemy));
        timer.Start();
    }

    public void OnAreaEntered(Area2D a_area)
    {
        if (a_area is not EnemyArea2d enemyArea)
        {
            return;
        }

        Enemy2d enemy = enemyArea.GetEnemy2D();
        if (enemy == null || enemiesInRange.Contains(enemy))
        {
            return;
        }
        enemiesInRange.Add(enemy);
    }

    public void OnAreaExited(Area2D a_area)
    {
        if(a_area is EnemyArea2d)
        {
           Enemy2d enemy = (a_area as EnemyArea2d).GetEnemy2D(); 

           while(enemiesInRange.Contains(enemy))
           {
                enemiesInRange.Remove(enemy);
           }
        }
    }

    public void OnTowerButtonPressed()
    {
        if (towerMenu.Visible)
        {
            towerMenu.Visible = false;
            return;
        }

        if(towerEnums != Towers.None)
        {
            GD.Print("There is already a tower here!");
            return;
        }

        ToggleTowerMenu();
    }

    public void ToggleTowerMenu()
    {
        towerMenu.Visible = !towerMenu.Visible;
    }

    public void InitialiseCannonTower()
    {
        if(towerEnums != Towers.None)
        {
            GD.Print("There is already a tower here!");
            return;
        }

        bool succes = Mana.Consume(50);

        if (!succes)
        {
            return;
        }

        towerEnums = Towers.Cannon;

        TowerSprite.Texture = cannonTowerTexture;
        damage = 3;
        timer.WaitTime = 0.5f;

        towerMenu.Visible = false;
    }

    public void InitialiseIceTower()
    {
        if(towerEnums != Towers.None)
        {
            GD.Print("There is already a tower here!");
            return;
        }

        bool succes = Mana.Consume(200);

        if (!succes)
        {
            return;
        }

        towerEnums = Towers.Ice;

        TowerSprite.Texture = iceTowerTexture;
        damage = 6;
        timer.WaitTime = 0.5f;

        towerMenu.Visible = false;
    }
}
