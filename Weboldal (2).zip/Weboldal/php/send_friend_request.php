<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

require __DIR__ . '/config.php';

$response = ["success" => false, "error" => ""];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    if ($db->connect_error) {
        throw new Exception($db->connect_error);
    }

    $username = $_POST["username"] ?? "";
    $sender_id = $_SESSION["user_id"];

    if (empty($username)) {
        $response["error"] = "Username is required";
        echo json_encode($response);
        exit;
    }

    // Get receiver user ID
    $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $response["error"] = "User not found";
        echo json_encode($response);
        $stmt->close();
        $db->close();
        exit;
    }

    $receiver = $result->fetch_assoc();
    $receiver_id = (int)$receiver["id"];
    $stmt->close();

    // Check if same user
    if ($sender_id === $receiver_id) {
        $response["error"] = "Cannot add yourself";
        echo json_encode($response);
        $db->close();
        exit;
    }

    // Check if already friends
    $stmt = $db->prepare("SELECT id FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
    $stmt->bind_param("iiii", $sender_id, $receiver_id, $receiver_id, $sender_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $response["error"] = "Already friends";
        echo json_encode($response);
        $stmt->close();
        $db->close();
        exit;
    }
    $stmt->close();

    // Check if request already exists
    $stmt = $db->prepare("SELECT id, status FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)");
    $stmt->bind_param("iiii", $sender_id, $receiver_id, $receiver_id, $sender_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $request = $result->fetch_assoc();
        if ($request["status"] === "pending") {
            $response["error"] = "Request already pending";
        } else {
            $response["error"] = "Request already exists";
        }
        echo json_encode($response);
        $stmt->close();
        $db->close();
        exit;
    }
    $stmt->close();

    // Insert friend request
    $stmt = $db->prepare("INSERT INTO friend_requests (sender_id, receiver_id, status) VALUES (?, ?, 'pending')");
    $stmt->bind_param("ii", $sender_id, $receiver_id);
    $stmt->execute();
    $stmt->close();

    $response["success"] = true;
    $response["message"] = "Friend request sent";

} catch (Exception $e) {
    $response["error"] = $e->getMessage();
    error_log($e->getMessage());
}

echo json_encode($response);
$db->close();
?>
