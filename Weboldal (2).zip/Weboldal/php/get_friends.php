<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

require __DIR__ . '/config.php';

$response = ["success" => false, "friends" => []];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    if ($db->connect_error) {
        throw new Exception($db->connect_error);
    }

    $user_id = $_SESSION["user_id"];

    // Get friends list
    $stmt = $db->prepare("
        SELECT u.id, u.username, u.avatar
        FROM friends f
        JOIN users u ON (f.friend_id = u.id OR f.user_id = u.id)
        WHERE (f.user_id = ? OR f.friend_id = ?) AND u.id != ?
        ORDER BY u.username ASC
    ");
    $stmt->bind_param("iii", $user_id, $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $response["friends"][] = [
            "id" => (int)$row["id"],
            "username" => $row["username"],
            "avatar" => $row["avatar"]
        ];
    }
    $stmt->close();

    $response["success"] = true;

} catch (Exception $e) {
    $response["error"] = $e->getMessage();
    error_log($e->getMessage());
}

echo json_encode($response);
if (isset($db)) $db->close();
?>
