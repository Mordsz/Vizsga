<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

require __DIR__ . '/config.php';

$response = ["success" => false, "error" => ""];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    if ($db->connect_error) {
        throw new Exception($db->connect_error);
    }

    $request_id = (int)($_POST["request_id"] ?? 0);
    $receiver_id = $_SESSION["user_id"];

    if ($request_id === 0) {
        $response["error"] = "Invalid request ID";
        echo json_encode($response);
        exit;
    }

    // Get friend request
    $stmt = $db->prepare("SELECT sender_id FROM friend_requests WHERE id = ? AND receiver_id = ? AND status = 'pending'");
    $stmt->bind_param("ii", $request_id, $receiver_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $response["error"] = "Request not found or already processed";
        echo json_encode($response);
        $stmt->close();
        $db->close();
        exit;
    }

    $request = $result->fetch_assoc();
    $sender_id = (int)$request["sender_id"];
    $stmt->close();

    // Start transaction
    $db->begin_transaction();

    try {
        // Update request status
        $stmt = $db->prepare("UPDATE friend_requests SET status = 'accepted' WHERE id = ?");
        $stmt->bind_param("i", $request_id);
        $stmt->execute();
        $stmt->close();

        // Add to friends table (both directions)
        $stmt = $db->prepare("INSERT INTO friends (user_id, friend_id) VALUES (?, ?), (?, ?)");
        $stmt->bind_param("iiii", $sender_id, $receiver_id, $receiver_id, $sender_id);
        $stmt->execute();
        $stmt->close();

        $db->commit();
        $response["success"] = true;
        $response["message"] = "Friend request accepted";

    } catch (Exception $e) {
        $db->rollback();
        throw $e;
    }

} catch (Exception $e) {
    $response["error"] = $e->getMessage();
    error_log($e->getMessage());
}

echo json_encode($response);
if (isset($db)) $db->close();
?>
