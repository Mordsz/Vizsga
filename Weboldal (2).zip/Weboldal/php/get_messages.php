<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

require __DIR__ . '/config.php';

$response = ["success" => false, "messages" => []];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    if ($db->connect_error) {
        throw new Exception($db->connect_error);
    }

    $user_id = $_SESSION["user_id"];
    $friend_id = (int)($_POST["friend_id"] ?? 0);
    $limit = (int)($_POST["limit"] ?? 50);

    if ($friend_id === 0) {
        $response["error"] = "Invalid friend ID";
        echo json_encode($response);
        exit;
    }

    if ($limit < 1 || $limit > 500) {
        $limit = 50;
    }

    // Delete expired messages
    $db->query("DELETE FROM messages WHERE expires_at < NOW()");

    // Get messages from conversation
    $stmt = $db->prepare("
        SELECT id, sender_id, message, created_at
        FROM messages
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
        ORDER BY created_at DESC
        LIMIT ?
    ");
    $stmt->bind_param("iiiii", $user_id, $friend_id, $friend_id, $user_id, $limit);
    $stmt->execute();
    $result = $stmt->get_result();

    $messages = [];
    while ($row = $result->fetch_assoc()) {
        $messages[] = [
            "id" => (int)$row["id"],
            "sender_id" => (int)$row["sender_id"],
            "message" => $row["message"],
            "created_at" => $row["created_at"],
            "is_own" => ((int)$row["sender_id"] === $user_id)
        ];
    }
    $stmt->close();

    // Reverse to get chronological order
    $response["messages"] = array_reverse($messages);
    $response["success"] = true;

} catch (Exception $e) {
    $response["error"] = $e->getMessage();
    error_log($e->getMessage());
}

echo json_encode($response);
if (isset($db)) $db->close();
?>
