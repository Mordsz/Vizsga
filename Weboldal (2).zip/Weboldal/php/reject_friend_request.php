<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

require __DIR__ . '/config.php';

$response = ["success" => false, "error" => ""];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    if ($db->connect_error) {
        throw new Exception($db->connect_error);
    }

    $request_id = (int)($_POST["request_id"] ?? 0);
    $receiver_id = $_SESSION["user_id"];

    if ($request_id === 0) {
        $response["error"] = "Invalid request ID";
        echo json_encode($response);
        exit;
    }

    // Update request status
    $stmt = $db->prepare("UPDATE friend_requests SET status = 'rejected' WHERE id = ? AND receiver_id = ? AND status = 'pending'");
    $stmt->bind_param("ii", $request_id, $receiver_id);
    $stmt->execute();

    if ($stmt->affected_rows === 0) {
        $response["error"] = "Request not found or already processed";
    } else {
        $response["success"] = true;
        $response["message"] = "Friend request rejected";
    }
    $stmt->close();

} catch (Exception $e) {
    $response["error"] = $e->getMessage();
    error_log($e->getMessage());
}

echo json_encode($response);
if (isset($db)) $db->close();
?>
