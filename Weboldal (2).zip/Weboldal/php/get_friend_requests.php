<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

require __DIR__ . '/config.php';

$response = ["success" => false, "requests" => []];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    if ($db->connect_error) {
        throw new Exception($db->connect_error);
    }

    $user_id = $_SESSION["user_id"];

    // Get pending friend requests
    $stmt = $db->prepare("
        SELECT fr.id, u.id as sender_id, u.username, u.avatar
        FROM friend_requests fr
        JOIN users u ON fr.sender_id = u.id
        WHERE fr.receiver_id = ? AND fr.status = 'pending'
        ORDER BY fr.created_at DESC
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $response["requests"][] = [
            "request_id" => (int)$row["id"],
            "sender_id" => (int)$row["sender_id"],
            "username" => $row["username"],
            "avatar" => $row["avatar"]
        ];
    }
    $stmt->close();

    $response["success"] = true;

} catch (Exception $e) {
    $response["error"] = $e->getMessage();
    error_log($e->getMessage());
}

echo json_encode($response);
if (isset($db)) $db->close();
?>
