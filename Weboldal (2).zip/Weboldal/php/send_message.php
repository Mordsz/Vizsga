<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

require __DIR__ . '/config.php';

$response = ["success" => false, "error" => ""];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    if ($db->connect_error) {
        throw new Exception($db->connect_error);
    }

    $sender_id = $_SESSION["user_id"];
    $receiver_id = (int)($_POST["receiver_id"] ?? 0);
    $message = trim($_POST["message"] ?? "");

    if ($receiver_id === 0) {
        $response["error"] = "Invalid receiver";
        echo json_encode($response);
        exit;
    }

    if (empty($message)) {
        $response["error"] = "Message cannot be empty";
        echo json_encode($response);
        exit;
    }

    if (strlen($message) > 5000) {
        $response["error"] = "Message too long";
        echo json_encode($response);
        exit;
    }

    // Check if they are friends
    $stmt = $db->prepare("
        SELECT id FROM friends 
        WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)
    ");
    $stmt->bind_param("iiii", $sender_id, $receiver_id, $receiver_id, $sender_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $response["error"] = "You are not friends";
        echo json_encode($response);
        $stmt->close();
        $db->close();
        exit;
    }
    $stmt->close();

    // Insert message
    $stmt = $db->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $sender_id, $receiver_id, $message);
    $stmt->execute();
    $message_id = $stmt->insert_id;
    $stmt->close();

    $response["success"] = true;
    $response["message_id"] = $message_id;

} catch (Exception $e) {
    $response["error"] = $e->getMessage();
    error_log($e->getMessage());
}

echo json_encode($response);
if (isset($db)) $db->close();
?>
