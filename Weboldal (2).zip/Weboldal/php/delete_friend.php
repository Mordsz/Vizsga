<?php
declare(strict_types=1);
session_start();

if (!isset($_SESSION["user_id"])) {
    echo json_encode(["success" => false, "error" => "Not logged in"]);
    exit;
}

require __DIR__ . '/config.php';

$response = ["success" => false, "error" => ""];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    if ($db->connect_error) {
        throw new Exception($db->connect_error);
    }

    $friend_id = (int)($_POST["friend_id"] ?? 0);
    $user_id = $_SESSION["user_id"];

    if ($friend_id === 0) {
        $response["error"] = "Invalid friend ID";
        echo json_encode($response);
        exit;
    }

    if ($user_id === $friend_id) {
        $response["error"] = "Cannot remove yourself";
        echo json_encode($response);
        exit;
    }

    // Remove friendship (both directions)
    $stmt = $db->prepare("DELETE FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
    $stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $response["success"] = true;
        $response["message"] = "Friend removed";
    } else {
        $response["error"] = "Friend not found";
    }
    $stmt->close();

} catch (Exception $e) {
    $response["error"] = $e->getMessage();
    error_log($e->getMessage());
}

echo json_encode($response);
if (isset($db)) $db->close();
?>
