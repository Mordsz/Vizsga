<?php
declare(strict_types=1);

session_start();
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require __DIR__ . '/config.php';

// Bejelentkezés ellenőrzése
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Nincs bejelentkezve']);
    exit;
}

$user_id = $_SESSION['user_id'];
$response = ['success' => false, 'message' => ''];

try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');

    // Jelenlegi felhasználó adatainak betöltése
    $stmt = $db->prepare('SELECT email, password FROM users WHERE id = ?');
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if (!$user) {
        throw new Exception('Felhasználó nem található');
    }

    $updates = [];
    $types = '';
    $values = [];

    // Személyes adatok frissítése
    if (!empty($_POST['first_name'])) {
        $first_name = trim($_POST['first_name']);
        $updates[] = 'first_name = ?';
        $types .= 's';
        $values[] = $first_name;
    }

    if (!empty($_POST['last_name'])) {
        $last_name = trim($_POST['last_name']);
        $updates[] = 'last_name = ?';
        $types .= 's';
        $values[] = $last_name;
    }

    if (isset($_POST['bio'])) {
        $bio = trim($_POST['bio']);
        $updates[] = 'bio = ?';
        $types .= 's';
        $values[] = $bio;
    }

    // Email módosítása
    if (!empty($_POST['email'])) {
        $new_email = trim($_POST['email']);
        $email_password = $_POST['email_password'] ?? '';

        if (empty($email_password)) {
            throw new Exception('Az email módosításához meg kell adnod a jelszavadat!');
        }

        if (!password_verify($email_password, $user['password'])) {
            throw new Exception('Helytelen jelszó!');
        }

        if ($new_email !== $user['email']) {
            // Email egyediség ellenőrzése
            $emailCheckStmt = $db->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
            $emailCheckStmt->bind_param('si', $new_email, $user_id);
            $emailCheckStmt->execute();
            $emailCheckStmt->store_result();

            if ($emailCheckStmt->num_rows > 0) {
                throw new Exception('Ez az email cím már használatban van!');
            }
            $emailCheckStmt->close();

            $updates[] = 'email = ?';
            $types .= 's';
            $values[] = $new_email;
        }
    }

    // Jelszó módosítása
    if (!empty($_POST['new_password'])) {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($current_password)) {
            throw new Exception('A jelszó módosításához meg kell adnod a jelenlegi jelszavadat!');
        }

        if (!password_verify($current_password, $user['password'])) {
            throw new Exception('A jelenlegi jelszó helytelen!');
        }

        if ($new_password !== $confirm_password) {
            throw new Exception('Az új jelszavak nem egyeznek!');
        }

        if (strlen($new_password) < 6) {
            throw new Exception('Az új jelszónak legalább 6 karakterből kell állnia!');
        }

        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
        $updates[] = 'password = ?';
        $types .= 's';
        $values[] = $hashed_password;
    }

    // Avatar feltöltés
    if (isset($_FILES['avatar']) && $_FILES['avatar']['size'] > 0) {
        $file = $_FILES['avatar'];
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 5 * 1024 * 1024; // 5MB

        if (!in_array($file['type'], $allowed_types)) {
            throw new Exception('Csak JPG, PNG vagy GIF fájlok engedélyezve!');
        }

        if ($file['size'] > $max_size) {
            throw new Exception('A fájl túl nagy (max 5MB)!');
        }

        $upload_dir = __DIR__ . '/../uploads/avatars/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        // Unique filename
        $file_ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $avatar_filename = 'avatar_' . $user_id . '_' . time() . '.' . $file_ext;
        $avatar_path = $upload_dir . $avatar_filename;

        if (move_uploaded_file($file['tmp_name'], $avatar_path)) {
            $avatar_url = 'uploads/avatars/' . $avatar_filename;
            $updates[] = 'avatar = ?';
            $types .= 's';
            $values[] = $avatar_url;
        } else {
            throw new Exception('Hiba a fájl feltöltésekor!');
        }
    }

    // If there are updates to make
    if (!empty($updates)) {
        $values[] = $user_id;
        $types .= 'i';

        $update_query = 'UPDATE users SET ' . implode(', ', $updates) . ' WHERE id = ?';
        $stmt = $db->prepare($update_query);
        $stmt->bind_param($types, ...$values);
        $stmt->execute();
        $stmt->close();

        $response['success'] = true;
        $response['message'] = 'Profil sikeresen frissítve!';
    } else {
        $response['message'] = 'Nincsenek módosítandó adatok!';
    }

    $db->close();

} catch (Exception $e) {
    $response['error'] = $e->getMessage();
    error_log('Profile update error: ' . $e->getMessage());
}

header('Content-Type: application/json');
echo json_encode($response);
