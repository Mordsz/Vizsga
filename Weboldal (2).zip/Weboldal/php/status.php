<?php
header('Content-Type: application/json');

echo json_encode([
    "canStart" => true,
    "message" => "Server online"
]);