// Chat System
class ChatSystem {
    constructor() {
        this.currentChatFriend = null;
        this.friends = [];
        this.pendingRequests = [];
        this.messageRefreshInterval = null;
        this.friendsRefreshInterval = null;
        this.init();
    }

    init() {
        // Load friends on page load
        this.loadFriends();
        this.loadPendingRequests();

        // Refresh friends and requests every 15 seconds
        this.friendsRefreshInterval = setInterval(() => {
            this.loadFriends();
            this.loadPendingRequests();
        }, 15000);

        // Setup event listeners
        this.setupEventListeners();
    }

    setupEventListeners() {
        const chatIcon = document.getElementById('chatIcon');
        if (chatIcon) {
            chatIcon.addEventListener('click', () => this.toggleChatPanel());
        }

        const closeChatBtn = document.getElementById('closeChatBtn');
        if (closeChatBtn) {
            closeChatBtn.addEventListener('click', () => this.toggleChatPanel());
        }

        const addFriendBtn = document.getElementById('addFriendBtn');
        if (addFriendBtn) {
            addFriendBtn.addEventListener('click', () => this.showAddFriendModal());
        }

        const addFriendForm = document.getElementById('addFriendForm');
        if (addFriendForm) {
            addFriendForm.addEventListener('submit', (e) => this.handleAddFriend(e));
        }

        const sendMessageBtn = document.getElementById('sendMessageBtn');
        if (sendMessageBtn) {
            sendMessageBtn.addEventListener('click', () => this.sendMessage());
        }

        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }

        // Tab switching
        const tabButtons = document.querySelectorAll('.chat-tab-btn');
        tabButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tabName = e.target.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });

        // Close modals when clicking outside
        const addFriendModal = document.getElementById('addFriendModal');
        if (addFriendModal) {
            window.addEventListener('click', (e) => {
                if (e.target === addFriendModal) {
                    addFriendModal.style.display = 'none';
                }
            });
        }
    }

    switchTab(tabName) {
        // Hide all tabs
        const tabs = document.querySelectorAll('.chat-tab');
        tabs.forEach(tab => tab.classList.remove('active'));
        
        // Remove active class from buttons
        const btns = document.querySelectorAll('.chat-tab-btn');
        btns.forEach(btn => btn.classList.remove('active'));
        
        // Show selected tab
        const selectedTab = document.getElementById(tabName + 'Tab');
        if (selectedTab) {
            selectedTab.classList.add('active');
        }
        
        // Add active class to clicked button
        const activeBtn = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }
    }

    async loadFriends() {
        try {
            const response = await fetch('php/get_friends.php', { method: 'POST' });
            const data = await response.json();

            if (data.success) {
                this.friends = data.friends;
                this.renderFriendsList();
            }
        } catch (error) {
            console.error('Error loading friends:', error);
        }
    }

    async loadPendingRequests() {
        try {
            const response = await fetch('php/get_friend_requests.php', { method: 'POST' });
            const data = await response.json();

            if (data.success) {
                this.pendingRequests = data.requests;
                this.renderPendingRequests();
                this.updatePendingBadge();
            }
        } catch (error) {
            console.error('Error loading pending requests:', error);
        }
    }

    renderFriendsList() {
        const friendsList = document.getElementById('friendsList');
        if (!friendsList) return;

        if (this.friends.length === 0) {
            friendsList.innerHTML = '<div class="no-friends">Nincsenek barátaid még</div>';
            return;
        }

        friendsList.innerHTML = this.friends.map(friend => `
            <div class="friend-item" data-friend-id="${friend.id}">
                <div class="friend-avatar" style="${friend.avatar ? `background-image: url(${friend.avatar})` : ''}">
                    ${!friend.avatar ? friend.username.substring(0, 1).toUpperCase() : ''}
                </div>
                <div class="friend-info">
                    <div class="friend-name">${friend.username}</div>
                </div>
                <div class="friend-actions">
                    <button class="friend-delete-btn" onclick="chatSystem.deleteFriend(${friend.id})">✕</button>
                    <button class="friend-chat-btn" onclick="chatSystem.openChat(${friend.id}, '${friend.username}')">💬</button>
                </div>
            </div>
        `).join('');
    }

    renderPendingRequests() {
        const requestsList = document.getElementById('friendRequestsList');
        if (!requestsList) return;

        if (this.pendingRequests.length === 0) {
            requestsList.innerHTML = '<div class="no-requests">Nincsenek függőben lévő kérések</div>';
            return;
        }

        requestsList.innerHTML = this.pendingRequests.map(request => `
            <div class="request-item" data-request-id="${request.request_id}">
                <div class="request-avatar" style="${request.avatar ? `background-image: url(${request.avatar})` : ''}">
                    ${!request.avatar ? request.username.substring(0, 1).toUpperCase() : ''}
                </div>
                <div class="request-info">
                    <div class="request-name">${request.username}</div>
                    <div class="request-text">Barátkérelem</div>
                </div>
                <div class="request-actions">
                    <button class="accept-btn" onclick="chatSystem.acceptRequest(${request.request_id})">✓</button>
                    <button class="reject-btn" onclick="chatSystem.rejectRequest(${request.request_id})">✕</button>
                </div>
            </div>
        `).join('');
    }

    updatePendingBadge() {
        const badge = document.getElementById('requestsNotificationBadge');
        if (badge) {
            if (this.pendingRequests.length > 0) {
                badge.style.display = 'inline-block';
                badge.textContent = this.pendingRequests.length;
            } else {
                badge.style.display = 'none';
            }
        }
    }

    toggleChatPanel() {
        const chatPanel = document.getElementById('chatPanel');
        if (chatPanel) {
            chatPanel.classList.toggle('active');
        }
    }

    showAddFriendModal() {
        const modal = document.getElementById('addFriendModal');
        if (modal) {
            modal.style.display = 'flex';
            const input = document.getElementById('usernameInput');
            if (input) input.focus();
        }
    }

    async handleAddFriend(e) {
        e.preventDefault();
        const input = document.getElementById('usernameInput');
        const username = input.value.trim();

        if (!username) {
            alert('Kérjük add meg egy felhasználó felhasználónevét');
            return;
        }

        const formData = new FormData();
        formData.append('username', username);

        try {
            const response = await fetch('php/send_friend_request.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                alert('Barátkérelem elküldve!');
                input.value = '';
                document.getElementById('addFriendModal').style.display = 'none';
            } else {
                alert('Hiba: ' + data.error);
            }
        } catch (error) {
            console.error('Error sending friend request:', error);
            alert('Hiba történt!');
        }
    }

    openChat(friendId, friendName) {
        this.currentChatFriend = { id: friendId, name: friendName };
        this.loadMessages();
        this.toggleChatPanel();
        this.startMessageRefresh();

        // Update chat header
        const chatHeader = document.getElementById('chatHeader');
        if (chatHeader) {
            chatHeader.textContent = `Csevegés: ${friendName}`;
        }
    }

    startMessageRefresh() {
        // Clear previous interval
        if (this.messageRefreshInterval) {
            clearInterval(this.messageRefreshInterval);
        }

        // Load messages immediately
        this.loadMessages();

        // Then refresh every 3 seconds
        this.messageRefreshInterval = setInterval(() => {
            if (this.currentChatFriend) {
                this.loadMessages();
            }
        }, 3000);
    }

    async loadMessages() {
        if (!this.currentChatFriend) return;

        const formData = new FormData();
        formData.append('friend_id', this.currentChatFriend.id);
        formData.append('limit', 100);

        try {
            const response = await fetch('php/get_messages.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                this.renderMessages(data.messages);
            }
        } catch (error) {
            console.error('Error loading messages:', error);
        }
    }

    renderMessages(messages) {
        const messagesContainer = document.getElementById('messagesContainer');
        if (!messagesContainer) return;

        messagesContainer.innerHTML = messages.map(msg => `
            <div class="message ${msg.is_own ? 'own-message' : 'friend-message'}">
                <div class="message-content">${this.escapeHtml(msg.message)}</div>
                <div class="message-time">${this.formatTime(msg.created_at)}</div>
            </div>
        `).join('');

        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    async sendMessage() {
        if (!this.currentChatFriend) {
            alert('Válassz egy barátot!');
            return;
        }

        const input = document.getElementById('messageInput');
        const message = input.value.trim();

        if (!message) return;

        const formData = new FormData();
        formData.append('receiver_id', this.currentChatFriend.id);
        formData.append('message', message);

        try {
            const response = await fetch('php/send_message.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                input.value = '';
                this.loadMessages();
            } else {
                alert('Hiba: ' + data.error);
            }
        } catch (error) {
            console.error('Error sending message:', error);
            alert('Hiba történt az üzenet küldésekor!');
        }
    }

    async deleteFriend(friendId) {
        if (!confirm('Biztosan eltávolítod ezt a barátot?')) return;

        const formData = new FormData();
        formData.append('friend_id', friendId);

        try {
            const response = await fetch('php/delete_friend.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                this.loadFriends();
                if (this.currentChatFriend && this.currentChatFriend.id === friendId) {
                    this.currentChatFriend = null;
                }
            } else {
                alert('Hiba: ' + data.error);
            }
        } catch (error) {
            console.error('Error deleting friend:', error);
        }
    }

    async acceptRequest(requestId) {
        const formData = new FormData();
        formData.append('request_id', requestId);

        try {
            const response = await fetch('php/accept_friend_request.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                this.loadPendingRequests();
                this.loadFriends();
            } else {
                alert('Hiba: ' + data.error);
            }
        } catch (error) {
            console.error('Error accepting request:', error);
        }
    }

    async rejectRequest(requestId) {
        const formData = new FormData();
        formData.append('request_id', requestId);

        try {
            const response = await fetch('php/reject_friend_request.php', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                this.loadPendingRequests();
            } else {
                alert('Hiba: ' + data.error);
            }
        } catch (error) {
            console.error('Error rejecting request:', error);
        }
    }

    formatTime(dateString) {
        const date = new Date(dateString);
        return date.toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' });
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    cleanup() {
        if (this.messageRefreshInterval) clearInterval(this.messageRefreshInterval);
        if (this.friendsRefreshInterval) clearInterval(this.friendsRefreshInterval);
    }
}

// Initialize chat system when page loads
let chatSystem;
document.addEventListener('DOMContentLoaded', () => {
    chatSystem = new ChatSystem();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (chatSystem) chatSystem.cleanup();
});
