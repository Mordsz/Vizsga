(function showLoginErrors() {
  const params = new URLSearchParams(window.location.search);
  const error = params.get('error');
  if (!error) {
    return;
  }

  const messages = {
    '1': 'Helytelen felhasználónév vagy jelszó.',
    missing: 'Mindkét mező kitöltése kötelező.',
    server: 'Váratlan hiba történt, próbáld meg később.'
  };

  const messageBox = document.getElementById('error-message');
  if (!messageBox) {
    return;
  }

  messageBox.textContent = messages[error] || 'Ismeretlen hiba történt.';
  messageBox.style.display = 'block';
})();

// Jelszó megjelenítés/elrejtés
document.addEventListener('DOMContentLoaded', function() {
  const togglePassword = document.getElementById('togglePassword');
  const passwordField = document.getElementById('passwordField');
  
  if (togglePassword && passwordField) {
    togglePassword.addEventListener('click', function(e) {
      e.preventDefault();
      if (passwordField.type === 'password') {
        passwordField.type = 'text';
        togglePassword.textContent = '👁️‍🗨️';
      } else {
        passwordField.type = 'password';
        togglePassword.textContent = '👁️‍🗨️';
      }
    });
  }
});