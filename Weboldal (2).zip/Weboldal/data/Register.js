// Regisztrációs hibaüzenetek megjelenítése
(function showRegisterErrors() {
  const params = new URLSearchParams(window.location.search);
  const error = params.get('error');
  const messageBox = document.getElementById('error-message');

  if (!messageBox || !error) {
    return;
  }

  const duplicateMessages = [];
  if (params.has('usernameExists')) {
    duplicateMessages.push('Létező felhasználó név');
  }
  if (params.has('emailExists')) {
    duplicateMessages.push('Létező email');
  }

  if (duplicateMessages.length > 0) {
    messageBox.innerHTML = duplicateMessages.join('<br><br>');
    messageBox.style.display = 'block';
    return;
  }

  const messages = {
    missing: 'Minden mezőt tölts ki.',
    email: 'Érvényes email címet adj meg.',
    password: 'A két jelszó nem egyezik.',
    server: 'Váratlan hiba történt, próbáld meg később.',
    exists: 'Már létezik ilyen felhasználó.'
  };

  messageBox.textContent = messages[error] || 'Ismeretlen hiba történt.';
  messageBox.style.display = 'block';
})();

// Jelszó megjelenítés/elrejtés
document.addEventListener('DOMContentLoaded', function() {
  const togglePassword1 = document.getElementById('togglePassword1');
  const passwordField = document.getElementById('passwordField');
  const togglePassword2 = document.getElementById('togglePassword2');
  const passwordConfirmField = document.getElementById('passwordConfirmField');
  
  if (togglePassword1 && passwordField) {
    togglePassword1.addEventListener('click', function(e) {
      e.preventDefault();
      if (passwordField.type === 'password') {
        passwordField.type = 'text';
        togglePassword1.textContent = '👁️‍🗨️';
      } else {
        passwordField.type = 'password';
        togglePassword1.textContent = '👁️‍🗨️';
      }
    });
  }
  
  if (togglePassword2 && passwordConfirmField) {
    togglePassword2.addEventListener('click', function(e) {
      e.preventDefault();
      if (passwordConfirmField.type === 'password') {
        passwordConfirmField.type = 'text';
        togglePassword2.textContent = '👁️‍🗨️';
      } else {
        passwordConfirmField.type = 'password';
        togglePassword2.textContent = '👁️‍🗨️';
      }
    });
  }
});
