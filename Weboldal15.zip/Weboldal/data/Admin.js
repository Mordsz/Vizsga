(() => {
  const dom = {
    tableBody: document.getElementById('userTableBody'),
    rowTemplate: document.getElementById('userRowTemplate'),
    filters: Array.from(document.querySelectorAll('.filter-btn')),
    searchInput: document.getElementById('userSearch'),
    adminMessage: document.getElementById('adminMessage'),
    notificationSection: document.getElementById('notificationSection'),
    registrationName: document.getElementById('registrationName'),
    registrationTitle: document.getElementById('registrationTitle'),
    closeNotification: document.getElementById('closeNotification'),
    stats: {
      total: document.getElementById('totalUsers'),
      online: document.getElementById('onlineUsers'),
      blocked: document.getElementById('blockedUsers'),
      admin: document.getElementById('adminUsers')
    }
  };

  const state = {
    users: [],
    filter: 'all',
    latestKnownCreatedAt: null,
    refreshTimer: null,
    notificationTimer: null
  };

  const fetchJson = async (url, options = {}) => {
    const response = await fetch(url, { credentials: 'same-origin', ...options });
    if (!response.ok) {
      throw new Error('Szerver hiba');
    }
    return response.json();
  };

  const setMessage = (type, text) => {
    if (!dom.adminMessage) return;
    if (!text) {
      dom.adminMessage.hidden = true;
      dom.adminMessage.textContent = '';
      dom.adminMessage.className = 'admin-message';
      return;
    }
    dom.adminMessage.hidden = false;
    dom.adminMessage.textContent = text;
    dom.adminMessage.className = `admin-message ${type}`;
  };

  async function loadUsers() {
    dom.tableBody.innerHTML = '<tr><td colspan="6" class="loading-row">Adatok betöltése...</td></tr>';

    try {
      const data = await fetchJson('php/admin_users.php');
      if (!data.success) {
        throw new Error(data.message || 'Hiba történt');
      }
      state.users = data.users || [];
      renderUsers();
      updateStats();
      setMessage();
    } catch (error) {
      setMessage('error', 'Nem sikerült betölteni a felhasználókat.');
      dom.tableBody.innerHTML = '<tr><td colspan="6" class="loading-row">Nem sikerült betölteni az adatokat.</td></tr>';
      console.error(error);
    }
  }

  function renderUsers() {
    const query = dom.searchInput.value.trim().toLowerCase();
    const filtered = state.users
      .filter(user => userMatchesFilter(user))
      .filter(user => userMatchesSearch(user, query));

    if (!filtered.length) {
      dom.tableBody.innerHTML = '<tr><td colspan="6" class="no-results">Nincs megjeleníthető felhasználó.</td></tr>';
      return;
    }

    const fragment = document.createDocumentFragment();
    filtered.forEach(user => fragment.appendChild(buildRow(user)));
    dom.tableBody.innerHTML = '';
    dom.tableBody.appendChild(fragment);
  }

  function buildRow(user) {
    const clone = dom.rowTemplate.content.cloneNode(true);
    const row = clone.querySelector('tr');
    const userName = clone.querySelector('.user-name');
    const userId = clone.querySelector('.user-id');

    userName.textContent = user.username;
    userId.textContent = `#${user.id}`;
    clone.querySelector('.user-email').textContent = user.email;

    const statusPill = clone.querySelector('.status-pill');
    statusPill.textContent = user.status === 'disabled' ? 'Letiltva' : (user.online ? 'Online' : 'Offline');
    statusPill.classList.toggle('online', user.status !== 'disabled' && user.online);
    statusPill.classList.toggle('offline', user.status !== 'disabled' && !user.online);
    statusPill.classList.toggle('disabled', user.status === 'disabled');

    const chatStatus = clone.querySelector('.chat-status');
    chatStatus.textContent = user.chat_enabled ? 'Engedélyezett' : 'Letiltva';

    clone.querySelector('.user-created').textContent = formatDate(user.created_at);

    const toggleBtn = clone.querySelector('.toggle-btn');
    toggleBtn.textContent = user.status === 'disabled' ? 'Engedélyez' : 'Letilt';
    toggleBtn.addEventListener('click', () => toggleStatus(user));

    const chatBtn = clone.querySelector('.chat-btn');
    chatBtn.textContent = user.chat_enabled ? 'Chat tiltás' : 'Chat feloldás';
    chatBtn.addEventListener('click', () => toggleChat(user));

    const deleteBtn = clone.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', () => deleteUser(user));

    return clone;
  }

  function userMatchesFilter(user) {
    if (state.filter === 'active') return user.status === 'active' && user.online;
    if (state.filter === 'offline') return user.status === 'active' && !user.online;
    if (state.filter === 'disabled') return user.status === 'disabled';
    return true;
  }

  function userMatchesSearch(user, query) {
    if (!query) return true;
    return user.username.toLowerCase().includes(query) || user.email.toLowerCase().includes(query);
  }

  function formatDate(value) {
    if (!value) return '-';
    const date = new Date(value.replace(' ', 'T'));
    return Number.isNaN(date.getTime()) ? value : date.toLocaleString('hu-HU', { hour12: false });
  }

  function updateStats() {
    const total = state.users.length;
    const online = state.users.filter(user => user.status === 'active' && user.online).length;
    const blocked = state.users.filter(user => user.status === 'disabled').length;
    const adminCount = state.users.filter(user => user.is_admin).length;

    dom.stats.total.textContent = total.toString();
    dom.stats.online.textContent = online.toString();
    dom.stats.blocked.textContent = blocked.toString();
    dom.stats.admin.textContent = adminCount.toString();
  }

  async function submitAction(payload, successMessage) {
    try {
      const formData = new FormData();
      Object.entries(payload).forEach(([key, value]) => formData.append(key, String(value)));
      const data = await fetchJson('php/admin_users.php', { method: 'POST', body: formData });
      if (!data.success) throw new Error(data.message || 'Hiba');
      setMessage('success', successMessage);
      await loadUsers();
    } catch (error) {
      setMessage('error', error.message || 'A művelet nem sikerült.');
      console.error(error);
    }
  }

  function toggleStatus(user) {
    const target = user.status === 'disabled' ? 'active' : 'disabled';
    if (!window.confirm(`Biztosan ${target === 'disabled' ? 'letiltod' : 'feloldod'} ${user.username} felhasználót?`)) {
      return;
    }
    submitAction({ action: 'toggle_status', user_id: user.id, status: target }, `${user.username} státusza frissítve.`);
  }

  function toggleChat(user) {
    const enabled = user.chat_enabled ? 0 : 1;
    const message = user.chat_enabled ? 'A chat letiltva.' : 'A chat engedélyezve.';
    if (!window.confirm(`Biztosan ${user.chat_enabled ? 'letiltod' : 'feloldod'} ${user.username} chatjét?`)) return;
    submitAction({ action: 'toggle_chat', user_id: user.id, enabled }, message);
  }

  function deleteUser(user) {
    if (!window.confirm(`Végleg törölni szeretnéd ${user.username} felhasználót? Ez nem visszavonható.`)) return;
    submitAction({ action: 'delete_user', user_id: user.id }, `${user.username} törölve.`);
  }

  async function checkNewRegistrations() {
    try {
      const data = await fetchJson('php/check_new_registrations.php');
      if (!data.success) return;
      const users = data.users || [];
      if (!users.length) return;

      const newest = users[0];
      if (!state.latestKnownCreatedAt) {
        state.latestKnownCreatedAt = newest.created_at;
        return;
      }

      const newUsers = users.filter(u => u.created_at > state.latestKnownCreatedAt);
      if (newUsers.length > 0) {
        state.latestKnownCreatedAt = users[0].created_at;
        showRegistrationNotification(newUsers);
      }
    } catch (error) {
      console.error('Registration poll failed', error);
    }
  }

  function showRegistrationNotification(newUsers) {
    if (!dom.notificationSection) return;
    const names = newUsers.map(user => user.username).join(', ');
    dom.registrationName.textContent = names;
    dom.registrationTitle.textContent = `Új regisztráció${newUsers.length > 1 ? 'k' : ''} érkezett!`;
    dom.notificationSection.hidden = false;
    window.clearTimeout(state.notificationTimer);
    state.notificationTimer = window.setTimeout(() => {
      dom.notificationSection.hidden = true;
    }, 15000);
  }

  function setupFilterButtons() {
    dom.filters.forEach(button => {
      button.addEventListener('click', event => {
        dom.filters.forEach(btn => btn.classList.remove('active'));
        event.currentTarget.classList.add('active');
        state.filter = event.currentTarget.dataset.filter || 'all';
        renderUsers();
      });
    });
  }

  function setupSearch() {
    dom.searchInput?.addEventListener('input', renderUsers);
  }

  function setupNotification() {
    dom.closeNotification?.addEventListener('click', () => {
      if (dom.notificationSection) dom.notificationSection.hidden = true;
    });
  }

  function init() {
    setupFilterButtons();
    setupSearch();
    setupNotification();
    loadUsers();
    checkNewRegistrations();
    setInterval(checkNewRegistrations, 60000);
    setInterval(loadUsers, 60000);
