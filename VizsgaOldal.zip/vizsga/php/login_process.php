<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../login.html");
    exit;
}

$username = $_POST["username"];
$password = $_POST["password"];

$file = "../data/users.json";
$users = json_decode(file_get_contents($file), true);

foreach ($users as $user) {
    if ($user["username"] === $username &&
        password_verify($password, $user["password"])) {

        $_SESSION["user"] = $username;
        header("Location: ../main.php");
        exit;
    }
}

header("Location: ../login.html?error=1");
exit;
