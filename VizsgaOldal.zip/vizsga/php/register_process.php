<?php
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../Regi.html");
    exit;
}

$username = trim($_POST["username"]);
$password = trim($_POST["password"]);

$file = "../data/users.json";
$users = json_decode(file_get_contents($file), true);

// Ellenőrzés: létezik-e
foreach ($users as $user) {
    if ($user["username"] === $username) {
        header("Location: ../Regi.html?error=exists");
        exit;
    }
}

// Új felhasználó mentése
$users[] = [
    "username" => $username,
    "password" => password_hash($password, PASSWORD_DEFAULT)
];

file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));

// Siker → login
header("Location: ../login.html?registered=1");

$email = trim($_POST["email"]);
$pass1 = $_POST["password"];
$pass2 = $_POST["password_confirm"];

if ($pass1 !== $pass2) {
    header("Location: ../register.html?error=password");
    exit;
}

$users[] = [
    "username" => $username,
    "email" => $email,
    "password" => password_hash($pass1, PASSWORD_DEFAULT)
];


exit;
