<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Főoldal</title>
<link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>

<div class="nav">
  <div class="nav-logo"></div>
  <div class="nav-title">TidesOfEnvy</div>
  <div class="nav-user">
    <div class="profile-pic"></div>
  </div>
</div>

<body>

<div class="nav">
  <div>LOGÓ</div>
  <div>TidesOfEnvy</div>
  <div><?= htmlspecialchars($_SESSION["user"]) ?></div>
</div>

<h2>Üdv a főoldalon!</h2>

<a href="php/logout.php">Kilépés</a>

</body>
</html>
